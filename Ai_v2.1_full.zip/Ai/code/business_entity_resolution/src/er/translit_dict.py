#!/usr/bin/env python3
"""Learn a token-level transliteration dictionary (Indic-script token -> Latin token) from the
TRAINING ground truth only (no external data).

S2/S3 records whose name is a transliteration of the S1 name keep word order and token count
("Krishna Foundation Private Limited" <-> "कृष्ण फाउंडेशन प्राइवेट लिमिटेड"), so aligned
positions give (non-ASCII token, Latin token) votes. Address tokens are aligned by
co-occurrence (a non-ASCII address token votes for every Latin token of the S1 address; the
winner must be clearly dominant). Output: JSON {token: latin_token}.

    python3 utils/build_translit_dict.py dataset/train work/translit.json
"""
import json
import re
import sys
from collections import Counter, defaultdict

import pandas as pd

_non_ascii = re.compile(r"[^\x00-\x7F]")
_punct = re.compile(r"[!-/:-@\[-`{-~]")  # ASCII punctuation only: never split inside Indic words (combining marks are not \w)


def toks(s):
    return _punct.sub(" ", str(s)).lower().split()


def main():
    d, out = sys.argv[1], sys.argv[2]
    rd = lambda p: pd.read_csv(p, sep="\t", dtype=str, keep_default_na=False, quoting=3)
    s1 = rd(f"{d}/train_source1.tsv").set_index("entity_id")
    pool = pd.concat([rd(f"{d}/train_source2.tsv"), rd(f"{d}/train_source3.tsv")]).set_index("entity_id")
    gt = rd(f"{d}/train_ground_truth.tsv")
    name_votes, addr_votes, addr_freq = defaultdict(Counter), defaultdict(Counter), Counter()
    n_pairs = 0
    pool_name, pool_addr = pool.business_name, pool.business_address
    for sid, ids in zip(gt.source1_entity_id, gt.matched_entity_ids):
        if not ids:
            continue
        s1n, s1a = None, None
        for m in ids.split(","):
            nm = pool_name.get(m, "")
            if not _non_ascii.search(nm):
                continue
            if s1n is None:
                s1n, s1a = toks(s1.business_name[sid]), toks(s1.business_address[sid])
            t2 = toks(nm)
            if len(t2) == len(s1n):
                for a, b in zip(t2, s1n):
                    if _non_ascii.search(a) and not _non_ascii.search(b):
                        name_votes[a][b] += 1
                n_pairs += 1
            for a in set(toks(pool_addr.get(m, ""))):
                if _non_ascii.search(a):
                    addr_freq[a] += 1
                    latin = [b for b in s1a if not _non_ascii.search(b)]
                    # unigram and bigram targets: one Indic token may stand for 'tamil nadu'
                    for b in set(latin) | {" ".join(x) for x in zip(latin, latin[1:])}:
                        addr_votes[a][b] += 1
    trans = {}
    for a, c in name_votes.items():
        b, n = c.most_common(1)[0]
        if n >= 2 and n / sum(c.values()) >= 0.5:
            trans[a] = b
    n_name = len(trans)
    for a, c in addr_votes.items():
        if a in trans:
            continue
        (b, n), = c.most_common(1)
        big = [(k, v) for k, v in c.items() if " " in k]
        if big:
            kb, nb = max(big, key=lambda kv: kv[1])
            if nb >= 0.9 * n:            # a bigram that co-occurs as often as the best unigram wins
                b, n = kb, nb
        if n >= 3 and n / addr_freq[a] >= 0.6:
            trans[a] = b
    json.dump(trans, open(out, "w"), ensure_ascii=False)
    print(f"aligned name pairs: {n_pairs:,}; dictionary: {n_name:,} name tokens + {len(trans) - n_name:,} address tokens -> {out}")


if __name__ == "__main__":
    main()
