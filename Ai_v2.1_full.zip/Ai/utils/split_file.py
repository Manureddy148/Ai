#!/usr/bin/env python3
"""Split a large file into numbered parts of at most `size_mb` MiB (default 29, under the
30 MiB per-file limit of the Claude app's file cards).

    python3 utils/split_file.py output/candidate_pairs.zip 29
-> output/candidate_pairs_part00.bin, candidate_pairs_part01.bin, ...
Rejoin with utils/join_parts.py (or `copy /b` on Windows, `cat` on Mac/Linux).
"""
import hashlib
import os
import sys


def main():
    path = sys.argv[1]
    size = int(float(sys.argv[2]) * (1 << 20)) if len(sys.argv) > 2 else 29 * (1 << 20)
    base = os.path.splitext(path)[0]
    h = hashlib.sha256()
    with open(path, "rb") as fi:
        k = 0
        while True:
            chunk = fi.read(size)
            if not chunk:
                break
            h.update(chunk)
            out = f"{base}_part{k:02d}.bin"
            with open(out, "wb") as fo:
                fo.write(chunk)
            print(f"wrote {out} ({len(chunk):,} bytes)")
            k += 1
    print(f"{k} parts; sha256 of the original: {h.hexdigest()}")


if __name__ == "__main__":
    main()
