#!/usr/bin/env python3
"""Join files that were split into numbered parts (e.g. matching_results_part00.bin, ...).

    python3 utils/join_parts.py matching_results_part matching_results.tsv
    python3 utils/join_parts.py candidate_pairs_part candidate_pairs.zip

The first argument is the common prefix of the parts (any directory), the second the output
file. Parts are concatenated in numeric order; a SHA-256 of the result is printed so it can
be compared with the value given alongside the parts. Equivalent shell commands:
    Windows:   cmd /c copy /b part00.bin+part01.bin+part02.bin out.tsv
    Mac/Linux: cat part00.bin part01.bin part02.bin > out.tsv
"""
import glob
import hashlib
import os
import re
import sys


def main():
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    prefix, out = sys.argv[1], sys.argv[2]
    parts = sorted(glob.glob(prefix + "*"), key=lambda p: [int(x) for x in re.findall(r"\d+", os.path.basename(p)[len(os.path.basename(prefix)):])])
    if not parts:
        sys.exit(f"no files match {prefix}*")
    h = hashlib.sha256()
    with open(out, "wb") as fo:
        for p in parts:
            with open(p, "rb") as fi:
                while True:
                    chunk = fi.read(1 << 24)
                    if not chunk:
                        break
                    fo.write(chunk)
                    h.update(chunk)
            print(f"appended {p} ({os.path.getsize(p):,} bytes)")
    print(f"wrote {out}: {os.path.getsize(out):,} bytes, sha256 {h.hexdigest()}")


if __name__ == "__main__":
    main()
