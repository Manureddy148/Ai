# er3 — Business Entity Resolution, v3.1 (bi-encoder + LightGBM + cross-encoder)

> v3.1 folds in the v2.1 improvements that lifted the CPU pipeline's validation macro F0.5
> from 0.878 to 0.926: a token transliteration dictionary learned from the training ground
> truth (`er3/translit_dict.py`, built automatically at `prep` into `work/translit.json`),
> legal-form and house-number *relation* features, house-number-free blocking keys, and
> streamed normalisation.

Standalone Python package for the **Amazon ML Challenge: Business Entity Resolution**:
link every Source-1 business record to its Source-2 / Source-3 records
(TSV inputs `entity_id, business_name, business_address, country`; train has US + India,
test adds France; metric = macro F0.5 per S1 entity, a singleton scores 1.0 iff the
prediction is empty). It writes the two required files, `matching_results.tsv` and
`candidate_pairs.tsv` (tab-separated, one row per test S1 entity, comma-joined
`S2-` / `S3-` ids).

v3 keeps the CPU pipeline of v2 (hash-key blocking, ~28 hand-crafted string / address
features, LightGBM, per-S1 decoding) and adds what v2 could not do on a CPU:

* a **fine-tuned multilingual bi-encoder** (`intfloat/multilingual-e5-small`, MIT) that
  embeds the *raw* strings — so Hindi / Tamil / Kannada transliterations, web-domain
  style names and reordered addresses land next to their Latin-script S1 record;
  it supplies extra candidates (ANN top-k inside the same country) and three neural
  features (`ann_sim`, `ann_rank`, `emb_cos`, plus their within-S1 gap / rank);
* a **fine-tuned cross-encoder** (`xlm-roberta-base`, MIT) that rescores only the pairs
  whose LightGBM probability is uncertain (band `[0.2, 0.98]`), blended with a weight
  tuned on validation;
* **per-country decision thresholds** (`thr`, `ratio`) tuned on a held-out validation
  sample scored against the *full* train pool; countries absent from train (France)
  use the global setting.

Everything runs on a Kaggle GPU kernel (T4 16 GB / P100, ~29 GB RAM, 12 h sessions),
every stage caches to `--work-dir` and is resumable, and the whole thing also runs on a
CPU with `--tiny` (locally built tiny models, no download) for the smoke test.

---

## Repository layout

```
v3/
├── README.md                 this file
├── requirements.txt          pinned minimum versions
├── pyproject.toml            `pip install -e .` gives an `er3` console script (optional)
├── src/er3/
│   ├── pipeline.py           the CLI: prep | finetune-embed | embed | block | features |
│   │                         train | crossenc | tune | test | all
│   ├── normalize.py          v2 normalisation (+ raw strings kept for the encoders)
│   ├── keys.py               v2 hash-key blocking (pool_index / block_chunks)
│   ├── embed.py              encode -> fp16 memmaps, chunked torch ANN top-k, pair cosine
│   ├── finetune.py           bi-encoder (MultipleNegativesRankingLoss) / cross-encoder training
│   ├── features.py           v2 pair features + neural features + within-S1 context
│   ├── model.py              LightGBM, decode table, vectorised macro F0.5, per-country tuning
│   ├── crossenc.py           cross-encoder loading / rescoring / band / blend
│   ├── tiny.py               tiny XLM-R style models + BPE tokenizer for the CPU smoke test
│   └── log.py                log(msg) with elapsed seconds
├── tests/
│   ├── smoke_test.py         end-to-end CPU test (synthetic data, tiny models)
│   ├── make_synthetic_dataset.py, validate_submission.py, score.py
└── notebooks/kaggle_v3.ipynb Kaggle notebook: one cell per stage
```

## Architecture (what each stage does)

| # | stage | device | what it produces in `--work-dir` |
|---|-------|--------|----------------------------------|
| 1 | `prep` | CPU | `s1_train.parquet`, `pool_train.parquet`, `s1_test.parquet`, `pool_test.parquet` (normalised + raw strings), `gt_train.npz` (ground-truth pair index), `split.npz` (train S1 sample **A**, validation S1 sample **B**, train pool subset **sub** = true matches of A + `--distractor-frac` of the pool) |
| 2 | `finetune-embed` | GPU | `biencoder/` — e5-small fine-tuned 1 epoch (fp16, in-batch negatives) on up to `--max-pairs` (S1, matched S2/S3) text pairs from the ground truth; pairs of the validation S1 are excluded so validation stays honest |
| 3 | `embed` | GPU | fp16 memmaps `emb_s1_train_A.npy`, `emb_s1_train_B.npy`, `emb_pool_train.npy` (full pool), `emb_pool_train_sub.npy`, `emb_s1_test.npy`, `emb_pool_test.npy`; text = `"{name_raw} | {addr_raw}"` with the e5 `query: ` prefix; resumable every 50k rows |
| 4 | `block` | GPU/CPU | `pairs_train.parquet` (A × sub), `pairs_val.parquet` (B × **full** pool): union of v2 hash-key pairs and ANN top-`--ann-k` cosine neighbours within the same country, columns `i1, i2, n_keys, ann_sim, ann_rank, emb_cos, y`; plus `ann_test_idx/sim.npy` for the test split |
| 5 | `features` | CPU | `X_train.parquet`, `X_val.parquet` — v2 features + `ann_sim, ann_rank, emb_cos, gap_emb, rank_emb` |
| 6 | `train` | CPU | `model.txt` (LightGBM, early stopping on 20 % of the S1 groups), `p_train.npy`, `p_val.npy` |
| 7 | `crossenc` | GPU | `ce/` — xlm-roberta-base fine-tuned 1 epoch on a balanced sample (≤ `--ce-max-train`) of band pairs from train + one half of the validation S1; `p_val_ce.npy`; `ce/w.json` with the blend weight `w ∈ {0, 0.3, 0.5, 0.7}` chosen on the *other* half of the validation S1 (0 = the cross-encoder does not help → it is skipped at test time) |
| 8 | `tune` | CPU | `tuned.json` — per-country `(thr, ratio)` grid search of macro F0.5 on the validation decode table (the tuning half when a cross-encoder is used, all of it otherwise); `__global__` is used for unseen countries (France) |
| 9 | `test` | CPU (+GPU for the cross-encoder) | streams test S1 in chunks of `--s1-chunk`: hash pairs ∪ ANN pairs → features → LightGBM → cross-encoder on the band (≤ `--ce-max-rescore` pairs in total, the ones closest to their country's threshold first) → `test_pairs_XXXX_{i1,i2,p,plgb}.npy` per chunk; then decode (each S2/S3 record goes to its best S1; keep if `p ≥ thr[country]` and `p ≥ ratio · best_p(S1)`) and write the two TSVs to `--out-dir` |

`all` runs the nine stages in order. Any stage that finds its outputs returns
immediately; delete a file (or the whole directory of a model) to recompute it.
`--no-embed` drops stages 2–3 and the ANN part of blocking (pure v2 candidates, neural
features set to their "absent" values); `--no-ce` drops stage 7 and the test-time rescoring.

---

## Install

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt        # or: pip install -e .
```

Python ≥ 3.10. `torch` with CUDA is needed for the GPU stages; the CPU build is enough
for the smoke test.

## CPU smoke test (no downloads, ~1 min)

```bash
python tests/smoke_test.py            # add --keep to inspect the temp dir
```

It writes a synthetic dataset, builds the tiny models with `er3.tiny`, runs
`pipeline.py all --tiny --device cpu --train-s1 1500 --val-s1 600 --distractor-frac 0.5
--ann-k 5 --max-pairs 3000 --ce-max-train 2000 --s1-chunk 500 --chunk-pairs 20000`,
then requires `validate_submission.py` to print `PASS` and `score.py` to report
macro F0.5 > 0.90 (it reaches ≈ 0.995). **The smoke-test score is not meaningful**: the
tiny models are random (2 layers, hidden 32, BPE vocab 2000, one epoch on a few thousand
synthetic pairs) and the synthetic data is easy for the hash keys + LightGBM alone, so on
synthetic data the cross-encoder blend weight is tuned to 0 — that is expected. The smoke
test only proves that every code path runs end-to-end, the caches resume and the output
format is right; the real quality of the neural stages only shows on the real data / GPU.

---

## Running on Kaggle (step by step)

### 0. Prepare
1. **Code**: zip this directory (`zip -r er3-code.zip v3 -x '*/work/*' '*/output/*'`) and
   upload it as a Kaggle *Dataset* (e.g. `er3-code`); or push it to a git repo and clone
   it from the notebook (needs Internet enabled).
2. **Data**: attach the competition dataset (it contains `train/` and `test/`).
3. **Notebook**: upload `notebooks/kaggle_v3.ipynb`, set *Accelerator* = GPU T4 (or P100)
   and *Internet* = On (Hugging Face downloads `intfloat/multilingual-e5-small` ≈ 470 MB
   and `xlm-roberta-base` ≈ 1.1 GB the first time; alternatively upload the two models as
   a dataset and pass `--embed-model /kaggle/input/...` / `--ce-model /kaggle/input/...`).

### 1. The notebook
The notebook has one cell per stage and calls exactly

```
python /kaggle/working/v3/src/er3/pipeline.py <stage> \
    --data-dir $DATA --work-dir /kaggle/working/work --out-dir /kaggle/working/output \
    --device cuda --workers 4
```

with the default flags below. Run the cells top to bottom. Each stage logs its progress
with elapsed seconds; the stage cells are safe to re-run (they resume).

### 2. GPU time budget (T4; P100 is ~1.3× faster on the neural parts)

| stage | ≈ time | notes |
|-------|--------|-------|
| `prep` | 10 min | 4 worker processes normalise 24 M strings |
| `finetune-embed` | 60 min | 1.5 M pairs, batch 256, fp16 |
| `embed` | 75 min per 12 M strings → **≈ 2.3 h total** | test split (1.73 M + 10 M) ≈ 75 min, full train pool (10.3 M) ≈ 65 min, the S1 samples ≈ 2 min. Use `--distractor-frac`/`--val-s1` to shrink the train side only if you must; the validation must see the full pool |
| `block` + `features` + `train` | 60 min | ANN over the full pools ≈ 15–25 min (the pool is streamed through the GPU once per query set: 1.73 M × 10 M × 384 fp16 matmul + top-k), hash keys ≈ 10 min, features ≈ 10 min, LightGBM ≈ 15–30 min (CPU) |
| `crossenc` | 30–45 min train + 10 min val rescoring | 300 k balanced pairs, batch 32, max_len 96 |
| `tune` | 2 min | |
| `test` | ≈ 2 h + ≤ 60–90 min cross-encoder rescoring | blocking + features + LightGBM for 1.73 M S1 ≈ 2 h; the cross-encoder rescoring is bounded by `--ce-max-rescore` (default 6 M pairs; xlm-roberta-base at max_len 96 does ≈ 1.5–2.5 k pairs/s on a T4, i.e. ≈ 1 h per 6 M — raise it only if you have the time) |

Total ≈ 8–9 h — inside one 12 h session only if nothing goes wrong. **Plan two
sessions** (see below). These are estimates, not measurements: watch the elapsed-seconds
log of the first `embed` / `block` / `test` chunk and extrapolate before committing to a plan.

### 3. Session / resume plan (Kaggle kills a session at 12 h)

`/kaggle/working` survives only when you **save a version**; an interactive session that
dies loses everything in it. The pipeline is designed around that:

* **Session 1** — set `RUN_STAGES = ["prep", "finetune-embed", "embed", "block", "features", "train"]`
  in the notebook's config cell and *Save Version → Save & Run All (Commit)*. Kaggle
  executes the notebook in the background (≈ 5–6 h) and stores `/kaggle/working`
  (`work/` with all caches) as the version's output. The optional cleanup cell removes
  the train-side embeddings after `block` so the output stays under Kaggle's 20 GB limit
  (`emb_pool_train.npy` alone is 7.9 GB).
* **Session 2** — in the notebook, *Add Input → Your Work → Notebooks → this notebook*
  (its latest version's output appears under `/kaggle/input/<notebook-slug>/`). The
  "restore" cell copies that `work/` back into `/kaggle/working/work`. Set
  `RUN_STAGES = ["crossenc", "tune", "test"]`, *Save & Run All* again (≈ 4 h). The version
  output now holds `output/matching_results.tsv`, `output/candidate_pairs.tsv` and
  `submission.zip`.
* Working interactively instead: run the cells one by one and commit (Save Version) after
  every long stage; the already-finished stages are skipped on the re-run because their
  caches are restored from the previous version. A stage interrupted half-way resumes
  from its own checkpoints (`embed` every 50 k rows, `test` per S1 chunk) only inside the
  same `/kaggle/working`, i.e. within the same session.
* Deleting a cache forces a recompute: e.g. `rm work/tuned.json` to re-tune,
  `rm -r work/ce` to retrain the cross-encoder, `rm work/test_pairs_*` to re-run the
  test split with new thresholds.

### 4. Submit
`output/matching_results.tsv` and `output/candidate_pairs.tsv` (validated by
`tests/validate_submission.py` in the notebook) are zipped into `submission.zip`.

---

## Flags reference (`pipeline.py <stage> ...`)

| flag | default | meaning |
|------|---------|---------|
| `--data-dir` | required | directory with `train/` and `test/` |
| `--work-dir` | `work` | cache directory (all intermediates) |
| `--out-dir` | `output` | where the two TSVs are written |
| `--device` | `auto` | `auto` = `cuda` if available else `cpu` |
| `--tiny` | off | build/use the tiny local models (`work/tiny_biencoder`, `work/tiny_crossencoder`) instead of downloading |
| `--no-ce` | off | skip the cross-encoder stage and test-time rescoring |
| `--no-embed` | off | skip the bi-encoder: hash-key candidates only, neural features absent |
| `--workers` | 4 | processes for normalisation, threads for rapidfuzz / LightGBM |
| `--train-s1` | 300000 | S1 entities sampled for LightGBM training (sample A) |
| `--val-s1` | 60000 | disjoint S1 sample scored against the full train pool (sample B) |
| `--distractor-frac` | 0.10 | fraction of the train pool added to A's true matches as distractors |
| `--cap` | 150 | hash keys shared by more than `cap` pool records are dropped |
| `--chunk-pairs` | 8000000 | pairs per feature / predict block (memory bound) |
| `--s1-chunk` | 100000 | test S1 rows per streamed chunk |
| `--ann-k` | 20 | ANN neighbours per S1 (same country) |
| `--embed-model` | `intfloat/multilingual-e5-small` | base bi-encoder (HF name or local dir) |
| `--ce-model` | `xlm-roberta-base` | base cross-encoder (HF name or local dir) |
| `--max-pairs` | 1500000 | ground-truth pairs used for bi-encoder fine-tuning |
| `--ce-lo` / `--ce-hi` | 0.2 / 0.98 | uncertain LightGBM band handed to the cross-encoder |
| `--ce-max-train` | 300000 | balanced cross-encoder training pairs |
| `--ce-max-rescore` | 6000000 | test pairs rescored by the cross-encoder (closest to their country's threshold first; ≈ 1 h per 6 M on a T4) |
| `--batch-size` | 256 | batch size for bi-encoder training (in-batch negatives) and cross-encoder rescoring; CPU training is capped at 32 |
| `--encode-batch` | 512 | batch size for embedding (inference only, max_len 64, fp16 autocast on GPU) |

Memory: every loop is chunked (`--chunk-pairs`, `--s1-chunk`, 50 k-row embedding
groups, 500 k-row cosine blocks; ANN = pool blocks of 500 k rows streamed once through
the GPU against query blocks of 2048 with the queries (≤ 3 GB) and the running top-k kept
on the device — ≈ 4 GB of GPU memory at peak). The largest resident CPU objects are the
prepped pool frame (≈ 6 GB for 10 M rows), the pool key index (≈ 1 GB) and the
concatenated test pairs `(i1, i2, p)` for decoding (≈ 1.5 GB for 135 M pairs, a few GB
transient while sorting); test features are only ever built per chunk.

## Work-dir files

```
s1_train.parquet pool_train.parquet s1_test.parquet pool_test.parquet   prepped frames
gt_train.npz split.npz                                                  ground truth index, A/B/sub
tiny_biencoder/ tiny_crossencoder/                                      (--tiny only)
biencoder/ (+ .done)                                                    fine-tuned bi-encoder
emb_s1_train_A.npy emb_s1_train_B.npy emb_pool_train.npy emb_pool_train_sub.npy
emb_s1_test.npy emb_pool_test.npy  (+ .shape.json, .progress)           fp16 embeddings
ann_train_*.npy ann_val_*.npy ann_test_*.npy                            ANN top-k tables
pairs_train.parquet pairs_val.parquet                                   candidate pairs + labels
X_train.parquet X_val.parquet                                           features (+ y, i1, i2)
model.txt p_train.npy p_val.npy                                         LightGBM + probabilities
ce/ (+ .done, w.json) p_val_ce.npy                                      cross-encoder, blend weight
tuned.json                                                              per-country (thr, ratio)
test_pairs_XXXX_{i1,i2,p,plgb}.npy                                      scored test chunks
```

## Design notes

* Validation is honest: sample B is disjoint from the LightGBM training sample, its
  ground-truth pairs are excluded from bi-encoder fine-tuning, and the cross-encoder is
  trained on one half of B while the blend weight and the thresholds are tuned on the
  other half.
* The ANN search is a chunked `torch.matmul` + `topk` over fp16 memmaps (no faiss),
  restricted to the same country, so it works identically on CPU and GPU (fp32 on CPU,
  fp16 on CUDA). fp16 autocast is used for embedding, bi-encoder / cross-encoder training
  (with a GradScaler) and rescoring on CUDA only; on CPU everything runs in fp32.
* `--device auto` picks `cuda` when `torch.cuda.is_available()`; the e5 `query: ` prefix
  is added exactly once (fine-tuning pairs and both sides of the embedding), never for
  the cross-encoder, which sees the plain `"{name_raw} | {addr_raw}"` text in its
  original script for training and rescoring alike.
* Version compatibility: sentence-transformers 3.x–6.x (`losses` import path,
  `tokenize`/`preprocess`, `activation_fct`/`activation_fn` are all handled) and
  torch ≥ 2.1 (`torch.amp.GradScaler` with the `torch.cuda.amp` fallback).
* Nothing touches the network at import time; HF names are resolved only when a model
  is actually loaded, which is why `--tiny` makes the whole pipeline offline.
