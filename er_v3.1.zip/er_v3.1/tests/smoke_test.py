#!/usr/bin/env python3
"""End-to-end CPU smoke test of the er3 pipeline on a synthetic dataset.

    python tests/smoke_test.py [--keep] [--work-dir DIR]

1. writes a synthetic dataset (tests/make_synthetic_dataset.py) into a temp dir,
2. builds the tiny bi-/cross-encoder with er3.tiny (no downloads),
3. runs ``pipeline.py all --tiny --device cpu`` with small samples and chunk sizes,
4. validates the two output TSVs (tests/validate_submission.py must PASS),
5. scores matching_results.tsv against the hidden synthetic truth (macro F0.5 > 0.90).

Exits non-zero on any failure. --keep leaves the temp dir in place for inspection.
"""
import argparse
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SRC = os.path.join(ROOT, "src")
PIPELINE = os.path.join(SRC, "er3", "pipeline.py")
MIN_F05 = 0.90

PIPELINE_FLAGS = ["--tiny", "--device", "cpu", "--train-s1", "1500", "--val-s1", "600", "--distractor-frac", "0.5",
                  "--ann-k", "5", "--max-pairs", "3000", "--ce-max-train", "2000",
                  "--s1-chunk", "500", "--chunk-pairs", "20000", "--batch-size", "64", "--workers", "2"]


def run(cmd, **kw):
    print("+ " + " ".join(cmd), flush=True)
    t = time.time()
    res = subprocess.run(cmd, text=True, **kw)
    print(f"  -> exit {res.returncode} in {time.time() - t:.1f}s", flush=True)
    return res


def fail(msg):
    print(f"SMOKE TEST FAILED: {msg}", flush=True)
    sys.exit(1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--keep", action="store_true", help="keep the temp directory")
    ap.add_argument("--work-dir", default=None, help="use this directory instead of a fresh temp dir")
    args = ap.parse_args()
    base = args.work_dir or tempfile.mkdtemp(prefix="er3_smoke_")
    os.makedirs(base, exist_ok=True)
    data, work, out = (os.path.join(base, d) for d in ("data", "work", "output"))
    env = dict(os.environ, PYTHONPATH=SRC + os.pathsep + os.environ.get("PYTHONPATH", ""))
    print(f"smoke test dir: {base}", flush=True)
    try:
        # 1. synthetic dataset
        if run([sys.executable, os.path.join(HERE, "make_synthetic_dataset.py"), data]).returncode:
            fail("make_synthetic_dataset.py failed")
        # 2. tiny models (the pipeline would build them itself under --tiny; do it explicitly here)
        sys.path.insert(0, SRC)
        import pandas as pd
        from er3.tiny import build_tiny_models
        corpus = []
        for f in ("train_source1.tsv", "train_source2.tsv", "train_source3.tsv"):
            df = pd.read_csv(os.path.join(data, "train", f), sep="\t", dtype=str, keep_default_na=False, quoting=3)
            corpus.extend((df.business_name + " | " + df.business_address).tolist())
        bi, ce = build_tiny_models(work, corpus)
        for d, marker in ((bi, "modules.json"), (ce, "config.json")):
            if not os.path.exists(os.path.join(d, marker)):
                fail(f"tiny model dir {d} lacks {marker}")
        # 3. the whole pipeline
        cmd = [sys.executable, PIPELINE, "all", "--data-dir", data, "--work-dir", work, "--out-dir", out] + PIPELINE_FLAGS
        if run(cmd, env=env).returncode:
            fail("pipeline 'all' failed")
        for f in ("matching_results.tsv", "candidate_pairs.tsv"):
            if not os.path.exists(os.path.join(out, f)):
                fail(f"missing output {f}")
        # 4. validation
        res = run([sys.executable, os.path.join(HERE, "validate_submission.py"), "--matching",
                   os.path.join(out, "matching_results.tsv"), "--candidate", os.path.join(out, "candidate_pairs.tsv"),
                   "--test-dir", os.path.join(data, "test")], capture_output=True)
        print(res.stdout)
        if res.returncode or "PASS" not in res.stdout:
            fail("validate_submission.py did not PASS\n" + res.stderr)
        # 5. score
        res = run([sys.executable, os.path.join(HERE, "score.py"), "--pred", os.path.join(out, "matching_results.tsv"),
                   "--truth", os.path.join(data, "test_ground_truth_hidden.tsv"),
                   "--source1", os.path.join(data, "test", "test_source1.tsv"), "--by-size"], capture_output=True)
        print(res.stdout)
        if res.returncode:
            fail("score.py failed\n" + res.stderr)
        m = re.search(r"Macro F0\.5\s*:\s*([0-9.]+)", res.stdout)
        if not m:
            fail("could not parse the macro F0.5 from score.py output")
        f05 = float(m.group(1))
        if f05 <= MIN_F05:
            fail(f"macro F0.5 {f05:.4f} <= {MIN_F05}")
        print(f"SMOKE TEST PASSED: macro F0.5 = {f05:.4f} (> {MIN_F05}); outputs in {out}", flush=True)
    finally:
        if args.keep or args.work_dir:
            print(f"kept {base}", flush=True)
        else:
            shutil.rmtree(base, ignore_errors=True)


if __name__ == "__main__":
    main()
