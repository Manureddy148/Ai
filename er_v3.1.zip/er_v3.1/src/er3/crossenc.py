"""Cross-encoder rescoring of the uncertain LightGBM probability band.

* ``load_crossencoder``: load a fine-tuned (or tiny) CrossEncoder onto a device.
* ``rescore``: batched ``CrossEncoder.predict`` over (text_a, text_b) pairs,
  returning calibrated probabilities in [0, 1] (raw logits + sigmoid, so the
  result never depends on the activation stored with the model). fp16 autocast
  is used on CUDA.
* ``select_band``: boolean mask of the pairs whose LightGBM p lies in [lo, hi].
* ``blend``: ``(1 - w) * p_lgb + w * p_ce``.

Nothing here touches the network at import time.
"""
from __future__ import annotations

import numpy as np

from .log import log

LOG_EVERY_PAIRS = 200_000


def _is_cuda(device):
    return str(device).startswith("cuda")


def load_crossencoder(model_dir, device="cpu", max_len=96):
    """Load a CrossEncoder (num_labels=1) from ``model_dir`` onto ``device``."""
    from sentence_transformers.cross_encoder import CrossEncoder
    model = CrossEncoder(str(model_dir), num_labels=1, max_length=int(max_len), device=str(device))
    model.model.eval()
    log(f"load_crossencoder: {model_dir} on {device} (max_len={max_len})")
    return model


def _activation_kwarg(model):
    """Name of ``CrossEncoder.predict``'s activation argument: ``activation_fn`` (ST >= 4)
    or ``activation_fct`` (ST 3.x)."""
    import inspect
    try:
        params = inspect.signature(model.predict).parameters
    except (TypeError, ValueError):
        return "activation_fn"
    return "activation_fn" if "activation_fn" in params else "activation_fct"


def _sigmoid(x):
    x = np.asarray(x, dtype=np.float64)
    return (1.0 / (1.0 + np.exp(-x))).astype(np.float32)


def rescore(model, texts_a, texts_b, batch_size=256, device="cpu", chunk=100_000):
    """Probability that each (texts_a[i], texts_b[i]) pair is a match; float32 in [0, 1].

    Predicts in chunks of ``chunk`` pairs (each internally batched by ``batch_size``)
    so that the tokenised tensors of a multi-million pair test set never sit in
    memory at once. Raw logits are requested (identity activation) and a sigmoid
    is applied here; if the model already emits probabilities (values in [0, 1]
    with num_labels != 1) they are clipped instead.
    """
    import torch

    n = len(texts_a)
    if n != len(texts_b):
        raise ValueError(f"rescore: len(texts_a)={n} != len(texts_b)={len(texts_b)}")
    out = np.zeros(n, dtype=np.float32)
    if n == 0:
        return out
    dev = str(device)
    use_amp = _is_cuda(dev)
    identity = torch.nn.Identity()
    act_kw = _activation_kwarg(model)
    last_logged = 0
    with torch.inference_mode():
        for start in range(0, n, int(chunk)):
            stop = min(n, start + int(chunk))
            pairs = [[str(a), str(b)] for a, b in zip(texts_a[start:stop], texts_b[start:stop])]
            with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=use_amp):
                raw = model.predict(pairs, batch_size=int(batch_size), show_progress_bar=False,
                                    convert_to_numpy=True, **{act_kw: identity})
            raw = np.asarray(raw, dtype=np.float32)
            if raw.ndim == 2:
                raw = raw[:, -1] if raw.shape[1] > 1 else raw[:, 0]
            out[start:stop] = _sigmoid(raw)
            if stop - last_logged >= LOG_EVERY_PAIRS or stop == n:
                log(f"rescore: {stop:,}/{n:,} pairs")
                last_logged = stop
    np.clip(out, 0.0, 1.0, out=out)
    return out


def select_band(p, lo=0.2, hi=0.98):
    """Boolean mask of pairs whose probability lies in the uncertain band [lo, hi]."""
    p = np.asarray(p, dtype=np.float32)
    return (p >= np.float32(lo)) & (p <= np.float32(hi))


def blend(p_lgb, p_ce, w=0.5):
    """``(1 - w) * p_lgb + w * p_ce`` as float32 (arrays must be aligned)."""
    p_lgb = np.asarray(p_lgb, dtype=np.float32)
    p_ce = np.asarray(p_ce, dtype=np.float32)
    w = np.float32(w)
    return ((np.float32(1.0) - w) * p_lgb + w * p_ce).astype(np.float32)
