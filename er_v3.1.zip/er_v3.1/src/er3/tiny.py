"""Locally built tiny bi-encoder / cross-encoder for the CPU smoke test (no downloads).

``build_tiny_models`` trains a byte-level BPE tokenizer (vocab 2000) on the given
corpus with the ``tokenizers`` library, wraps it as a ``PreTrainedTokenizerFast``
with XLM-R style special tokens (``<s>``=0, ``<pad>``=1, ``</s>``=2, ``<unk>``=3,
``<mask>``=4) and a RoBERTa post-processor (``<s> A </s></s> B </s>``), and
saves two randomly initialised XLM-RoBERTa models (hidden 32, 2 layers, 2 heads,
intermediate 64):

* ``biencoder_dir``   : full SentenceTransformer layout (Transformer + mean Pooling),
  loadable with ``SentenceTransformer(biencoder_dir)``;
* ``crossencoder_dir``: ``XLMRobertaForSequenceClassification`` (num_labels=1) +
  tokenizer, loadable with ``CrossEncoder(crossencoder_dir)``.

Both are verified by loading and running one example before returning.
"""
from __future__ import annotations

import os
import shutil

from .log import log

VOCAB_SIZE = 2000
HIDDEN = 32
LAYERS = 2
HEADS = 2
INTERMEDIATE = 64
MAX_POS = 130            # >= max_len (96) + padding_idx (1) + 2
BI_MAX_LEN = 64
CE_MAX_LEN = 96
SPECIAL = ["<s>", "<pad>", "</s>", "<unk>", "<mask>"]


def _train_tokenizer(corpus_texts, vocab_size=VOCAB_SIZE):
    """Byte-level BPE ``tokenizers.Tokenizer`` trained on ``corpus_texts``."""
    from tokenizers import Tokenizer, decoders, models, pre_tokenizers, processors, trainers

    tok = Tokenizer(models.BPE(unk_token="<unk>"))
    tok.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=False)
    tok.decoder = decoders.ByteLevel()
    trainer = trainers.BpeTrainer(vocab_size=int(vocab_size), min_frequency=1,
                                  special_tokens=list(SPECIAL), show_progress=False,
                                  initial_alphabet=pre_tokenizers.ByteLevel.alphabet())
    texts = [str(t) for t in corpus_texts if t is not None and str(t)]
    if not texts:
        texts = ["business name | street 1, city"]
    tok.train_from_iterator(texts, trainer=trainer, length=len(texts))
    sep_id = tok.token_to_id("</s>")
    cls_id = tok.token_to_id("<s>")
    # positional: the keyword is `cls` or `cls_token` depending on the tokenizers version
    tok.post_processor = processors.RobertaProcessing(("</s>", sep_id), ("<s>", cls_id),
                                                      trim_offsets=True, add_prefix_space=False)
    return tok


def _wrap_tokenizer(tok):
    """``PreTrainedTokenizerFast`` around a trained ``tokenizers.Tokenizer``."""
    from transformers import PreTrainedTokenizerFast
    return PreTrainedTokenizerFast(tokenizer_object=tok, bos_token="<s>", eos_token="</s>",
                                   sep_token="</s>", cls_token="<s>", unk_token="<unk>",
                                   pad_token="<pad>", mask_token="<mask>",
                                   model_max_length=MAX_POS - 2)


def _config(hf_tok, num_labels=None):
    from transformers import XLMRobertaConfig
    kw = dict(vocab_size=len(hf_tok) + 5, hidden_size=HIDDEN, num_hidden_layers=LAYERS,
              num_attention_heads=HEADS, intermediate_size=INTERMEDIATE,
              max_position_embeddings=MAX_POS, pad_token_id=hf_tok.pad_token_id,
              bos_token_id=hf_tok.bos_token_id, eos_token_id=hf_tok.eos_token_id,
              type_vocab_size=1, layer_norm_eps=1e-5)
    if num_labels is not None:
        kw["num_labels"] = int(num_labels)
    return XLMRobertaConfig(**kw)


def _build_biencoder(hf_tok, biencoder_dir):
    import torch
    from transformers import XLMRobertaModel
    from sentence_transformers import SentenceTransformer, models

    hf_dir = os.path.join(biencoder_dir, "_hf")
    if os.path.isdir(biencoder_dir):
        shutil.rmtree(biencoder_dir)
    os.makedirs(hf_dir, exist_ok=True)
    torch.manual_seed(0)
    base = XLMRobertaModel(_config(hf_tok))       # keep the pooler: AutoModel expects it
    base.save_pretrained(hf_dir)
    hf_tok.save_pretrained(hf_dir)
    transformer = models.Transformer(hf_dir, max_seq_length=BI_MAX_LEN)
    pooling = models.Pooling(HIDDEN, pooling_mode="mean")
    st = SentenceTransformer(modules=[transformer, pooling], device="cpu")
    st.save(biencoder_dir)
    shutil.rmtree(hf_dir, ignore_errors=True)
    return biencoder_dir


def _build_crossencoder(hf_tok, crossencoder_dir):
    import torch
    from transformers import XLMRobertaForSequenceClassification

    if os.path.isdir(crossencoder_dir):
        shutil.rmtree(crossencoder_dir)
    os.makedirs(crossencoder_dir, exist_ok=True)
    torch.manual_seed(1)
    clf = XLMRobertaForSequenceClassification(_config(hf_tok, num_labels=1))
    clf.save_pretrained(crossencoder_dir)
    hf_tok.save_pretrained(crossencoder_dir)
    return crossencoder_dir


def _verify(biencoder_dir, crossencoder_dir):
    import numpy as np
    from sentence_transformers import SentenceTransformer
    from sentence_transformers.cross_encoder import CrossEncoder

    st = SentenceTransformer(biencoder_dir, device="cpu")
    emb = st.encode(["query: acme corp | 12 main st, springfield"], convert_to_numpy=True,
                    show_progress_bar=False)
    if emb.shape != (1, HIDDEN) or not np.all(np.isfinite(emb)):
        raise RuntimeError(f"tiny biencoder verification failed: shape {emb.shape}")
    ce = CrossEncoder(crossencoder_dir, num_labels=1, max_length=CE_MAX_LEN, device="cpu")
    p = ce.predict([["acme corp | 12 main st", "acme corporation | 12 main street"]],
                   show_progress_bar=False)
    p = np.asarray(p, dtype=np.float32).reshape(-1)
    if p.shape != (1,) or not np.isfinite(p[0]):
        raise RuntimeError(f"tiny crossencoder verification failed: {p}")
    log(f"build_tiny_models: verified biencoder dim={emb.shape[1]} and crossencoder p={p[0]:.3f}")


def build_tiny_models(work_dir, corpus_texts, vocab_size=VOCAB_SIZE):
    """Train a BPE tokenizer on ``corpus_texts`` and save tiny XLM-R models under
    ``work_dir``; returns ``(biencoder_dir, crossencoder_dir)``.

    The models are random (untrained) and only meaningful after
    ``er3.finetune`` fine-tuning; they exist so the full pipeline runs on CPU
    without any download. Rebuilds from scratch on every call.
    """
    work_dir = str(work_dir)
    os.makedirs(work_dir, exist_ok=True)
    biencoder_dir = os.path.join(work_dir, "tiny_biencoder")
    crossencoder_dir = os.path.join(work_dir, "tiny_crossencoder")

    corpus = list(corpus_texts)
    log(f"build_tiny_models: training BPE tokenizer (vocab {vocab_size}) on {len(corpus):,} texts")
    tok = _train_tokenizer(corpus, vocab_size)
    hf_tok = _wrap_tokenizer(tok)
    log(f"build_tiny_models: tokenizer vocab={len(hf_tok):,} pad={hf_tok.pad_token_id} "
        f"bos={hf_tok.bos_token_id} eos={hf_tok.eos_token_id}")
    _build_biencoder(hf_tok, biencoder_dir)
    _build_crossencoder(hf_tok, crossencoder_dir)
    _verify(biencoder_dir, crossencoder_dir)
    log(f"build_tiny_models: biencoder -> {biencoder_dir}, crossencoder -> {crossencoder_dir}")
    return biencoder_dir, crossencoder_dir
