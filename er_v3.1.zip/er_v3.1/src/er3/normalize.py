"""Text normalisation for business names and addresses (adapted from v2).

All functions are pure and operate on single strings; `prep()` applies them to a whole
source frame with a process pool because the corpus has ~10M records per split. v3
additionally keeps the raw strings (name_raw, addr_raw) for the neural encoders,
which work on the original script rather than the ASCII-folded form.
"""
import json
import re
from multiprocessing import Pool

import numpy as np
import pandas as pd
from unidecode import unidecode

NAME_ABBR = {
    "corp": "corporation", "co": "company", "inc": "incorporated", "ltd": "limited",
    "pvt": "private", "intl": "international", "mfg": "manufacturing", "svc": "services",
    "svcs": "services", "bros": "brothers", "assoc": "associates", "natl": "national",
    "tech": "technologies", "grp": "group", "ent": "enterprises", "cie": "compagnie",
    "ste": "societe", "llp": "llp",
}
LEGAL = {
    "corporation", "company", "incorporated", "limited", "private", "llc", "llp", "lp",
    "plc", "pllc", "the", "and", "of", "dba", "pvt", "opc", "inc", "ltd", "co",
    "sarl", "sas", "sasu", "sa", "eurl", "sci", "snc", "societe", "compagnie", "et",
}
TLD = {"com", "in", "net", "org", "co", "io", "fr", "us", "biz", "info"}
ADDR_ABBR = {
    "rd": "road", "st": "street", "str": "street", "ave": "avenue", "av": "avenue",
    "blvd": "boulevard", "bd": "boulevard", "dr": "drive", "ln": "lane", "hwy": "highway",
    "pkwy": "parkway", "ct": "court", "pl": "place", "sq": "square", "ste": "suite",
    "apt": "apartment", "fl": "floor", "flr": "floor", "bldg": "building",
    "nr": "near", "opp": "opposite", "ngr": "nagar", "clny": "colony", "sec": "sector",
    "mkt": "market", "stn": "station", "marg": "road", "salai": "road",
    "fbg": "faubourg", "chem": "chemin", "imp": "impasse",
}
ADDR_STOP = {"near", "opposite", "behind", "beside", "next", "to", "the", "of", "and",
             "no", "number", "de", "la", "le", "du", "des", "null", "none", "nan", "n", "a"}

_punct = re.compile(r"[^a-z0-9 ]+")
_space = re.compile(r"\s+")
_digits = re.compile(r"\d+")
_postal = re.compile(r"\b(\d{5,6})\b")
_dotted = re.compile(r"(?<![a-z])(?:[a-z]\.){2,}[a-z]?(?![a-z])")
_ALIAS = re.compile(
    r"\b(?:d\s*/\s*b\s*/\s*a|d\.b\.a\.?|dba|doing business as|trading as|t\s*/\s*a"
    r"|a\s*/\s*k\s*/\s*a|a\.k\.a\.?|also known as|formerly(?: known as)?)\b", re.I)
_NULLS = {"", "null", "none", "nan", "n/a", "na", "-"}
_ascii_punct = re.compile(r"[!-/:-@\[-`{-~]")
_non_ascii = re.compile(r"[^\x00-\x7F]")

# canonical legal form of a raw name (last legal token); '' when none
_LEGAL_RE = re.compile(
    r"\b(private\s+limited|pvt\.?\s*ltd\.?|pvt|ltd|limited|l\.?l\.?c|l\.?l\.?p|inc(?:orporated)?"
    r"|corp(?:oration)?|co(?:mpany)?|p\.?l\.?l\.?c|p\.?c|plc|sarl|sasu|sas|eurl|gmbh)\b\.?", re.I)
_LEGAL_CANON = {"private limited": "pvtltd", "pvt ltd": "pvtltd", "pvt": "pvt", "ltd": "ltd", "limited": "ltd",
                "llc": "llc", "llp": "llp", "inc": "inc", "incorporated": "inc", "corp": "corp",
                "corporation": "corp", "co": "co", "company": "co", "pllc": "pllc", "pc": "pc", "plc": "plc",
                "sarl": "sarl", "sasu": "sasu", "sas": "sas", "eurl": "eurl", "gmbh": "gmbh"}

TRANSLIT = {}


def set_translit(path_or_dict):
    """Install the token dictionary learned from the training ground truth
    (er3.translit_dict); module global, inherited by forked workers."""
    global TRANSLIT
    TRANSLIT = path_or_dict if isinstance(path_or_dict, dict) else json.load(open(path_or_dict))


def translit(s):
    """Replace known non-ASCII tokens by their Latin equivalent (before ASCII folding)."""
    if not _non_ascii.search(s):
        return s
    out = []
    for t in _ascii_punct.sub(" ", s).lower().split():
        for w in (TRANSLIT.get(t, t) if _non_ascii.search(t) else t).split():
            if not out or out[-1] != w:      # 'uttar pradesh' + 'pradesh' -> 'uttar pradesh'
                out.append(w)
    return " ".join(out)


def legal_form(raw):
    m = _LEGAL_RE.findall(str(raw))
    if not m:
        return ""
    k = re.sub(r"[.\s]+", " ", m[-1].lower()).strip()
    return _LEGAL_CANON.get(k, _LEGAL_CANON.get(k.replace(" ", ""), k))


def clean_raw(s):
    """Raw string for the neural encoders: str(), whitespace-collapsed, 'null'-like -> ''."""
    if s is None or (isinstance(s, float) and np.isnan(s)):
        return ""
    s = _space.sub(" ", str(s)).strip()
    return "" if s.lower() in _NULLS else s


def basic(s):
    """Transliterate (learned dictionary), ASCII-fold, lowercase, strip punctuation."""
    s = unidecode(translit(str(s))).lower()
    s = s.replace("&", " and ").replace("@", " at ")
    s = _dotted.sub(lambda m: m.group(0).replace(".", ""), s)
    s = _punct.sub(" ", s)
    return _space.sub(" ", s).strip()


def norm_name(raw):
    """Normalised name with legal suffixes and web TLDs removed ('core name')."""
    s = basic(" ".join(_ALIAS.split(str(raw))))
    toks = [NAME_ABBR.get(t, t) for t in s.split()]
    if len(toks) > 1 and toks[-1] in TLD:          # 'maurewilliams com' -> 'maurewilliams'
        toks = toks[:-1]
    core = [t for t in toks if t not in LEGAL]
    return " ".join(core) if core else " ".join(toks)


def norm_addr(raw):
    """Normalised address with abbreviations expanded and filler tokens removed.

    Returns (addr_c, postal, house, nums) where postal is the 5-6 digit code (last one
    in the raw string), house the first token containing a digit, and nums the
    space-joined digit runs excluding the postal code.
    """
    postal = (_postal.findall(str(raw)) or [""])[-1]
    s = basic(raw)
    toks = [ADDR_ABBR.get(t, t) for t in s.split()]
    toks = [t for t in toks if t not in ADDR_STOP]
    house = next((t for t in toks if any(c.isdigit() for c in t)), "")
    nums = _digits.findall(s)
    if postal and postal in nums:
        nums.remove(postal)
    return " ".join(toks), postal, house, " ".join(dict.fromkeys(nums))


def _prep_chunk(args):
    names, addrs = args
    return [norm_name(n) for n in names], [norm_addr(a) for a in addrs], [legal_form(n) for n in names]


def _str_col(values):
    return pd.Series(values, dtype="string[pyarrow]")


def prep(df, workers=4, chunk=50_000):
    """Normalise a source frame (entity_id, business_name, business_address, country).

    Returns DataFrame[entity_id, country, name_c, addr_c, postal, house, nums,
    legal, non_ascii(int8), src('S1'/'S2'/'S3'), name_raw, addr_raw]; country is lower-cased
    ASCII, name_raw/addr_raw are the original strings ('null'-like tokens -> '').
    """
    name_raw = [clean_raw(s) for s in df.business_name.tolist()]
    addr_raw = [clean_raw(s) for s in df.business_address.tolist()]
    jobs = [(name_raw[i:i + chunk], addr_raw[i:i + chunk]) for i in range(0, len(df), chunk)]
    name_c, addr_rows, legal = [], [], []
    if workers and workers > 1 and len(jobs) > 1:
        with Pool(workers) as pool:
            for n, a, l in pool.imap(_prep_chunk, jobs):
                name_c.extend(n); addr_rows.extend(a); legal.extend(l)
    else:
        for job in jobs:
            n, a, l = _prep_chunk(job)
            name_c.extend(n); addr_rows.extend(a); legal.extend(l)
    non_ascii = np.fromiter((any(ord(c) > 127 for c in s) for s in name_raw), dtype=np.int8, count=len(name_raw))
    ids = df.entity_id.astype(str)
    return pd.DataFrame({
        "entity_id": ids.to_numpy(dtype=object),
        "country": _str_col([basic(c) for c in df.country.tolist()]),
        "name_c": _str_col(name_c),
        "addr_c": _str_col([r[0] for r in addr_rows]),
        "postal": _str_col([r[1] for r in addr_rows]),
        "house": _str_col([r[2] for r in addr_rows]),
        "nums": _str_col([r[3] for r in addr_rows]),
        "legal": _str_col(legal),
        "non_ascii": non_ascii,
        "src": ids.str[:2].to_numpy(dtype=object),
        "name_raw": _str_col(name_raw),
        "addr_raw": _str_col(addr_raw),
    })
