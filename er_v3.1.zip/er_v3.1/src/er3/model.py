"""LightGBM matcher, per-S1 decoding, vectorised macro-F0.5 and per-country tuning.

Adapted from v2: `train`, `decode_table`, `macro_f05` are unchanged in spirit; v3 makes
`decide` take a per-row threshold array (thresholds differ per country) and tunes
(thr, ratio) independently per country on the validation decode table, with a
'__global__' entry used for countries absent from validation (e.g. France in test).
"""
import lightgbm as lgb
import numpy as np
import pandas as pd

from .log import log

GLOBAL = "__global__"
RATIOS = (0.0, 0.5, 0.6, 0.7, 0.8, 0.9)
THRS = np.arange(0.10, 0.96, 0.025)

PARAMS = dict(objective="binary", learning_rate=0.05, num_leaves=127, min_child_samples=100,
              feature_fraction=0.8, bagging_fraction=0.8, bagging_freq=1, lambda_l2=1.0,
              verbose=-1, n_jobs=4, seed=42, deterministic=True, force_row_wise=True)


# ----------------------------------------------------------------------------- training
def train(X, y, groups, rounds=3000, patience=100, params=None):
    """Train with an internal group-held-out early-stopping split (20% of S1 groups).

    X: DataFrame[FEATURES]; y: 0/1 labels; groups: S1 index per row. `params` overrides PARAMS.
    """
    p = dict(PARAMS, **(params or {}))
    y = np.asarray(y)
    groups = np.asarray(groups)
    rng = np.random.default_rng(0)
    g = np.unique(groups)
    hold = np.isin(groups, rng.choice(g, size=max(1, len(g) // 5), replace=False))
    dtr = lgb.Dataset(X[~hold], y[~hold])
    dva = lgb.Dataset(X[hold], y[hold])
    m = lgb.train(p, dtr, rounds, valid_sets=[dva], callbacks=[lgb.early_stopping(patience, verbose=False)])
    log(f"model: best_iter={m.best_iteration}, train pairs={(~hold).sum():,}, holdout pairs={hold.sum():,}, "
        f"pos rate={y.mean():.4f}")
    imp = pd.Series(m.feature_importance("gain"), X.columns).sort_values(ascending=False)
    log("feature importance (gain, top 15): " + ", ".join(f"{k}={v:.0f}" for k, v in imp.head(15).items()))
    return m


# ----------------------------------------------------------------------------- decoding
def decode_table(i1, i2, p):
    """Assign each S2/S3 record to its best-scoring S1; record the best p per S1.

    Returns DataFrame[i1, i2, p, best] with one row per distinct i2.
    """
    d = pd.DataFrame({"i1": np.asarray(i1), "i2": np.asarray(i2), "p": np.asarray(p, dtype=np.float32)})
    d = d.sort_values("p", ascending=False, kind="stable").drop_duplicates("i2")
    d["best"] = d.groupby("i1").p.transform("max")
    return d.reset_index(drop=True)


def _mask(d, thr, ratio):
    p, best = d.p.to_numpy(), d.best.to_numpy()
    return (p >= thr) & (p >= ratio * best)


def decide(d, thr, ratio):
    """Rows of the decode table kept: p >= thr and p >= ratio * best(S1).

    `thr` (and optionally `ratio`) may be scalars or arrays aligned with the rows of `d`.
    """
    return d[_mask(d, np.asarray(thr, dtype=np.float32), np.asarray(ratio, dtype=np.float32))]


# ----------------------------------------------------------------------------- scoring
def f05_per_entity(pred_i1, pred_y, n_true, n_s1):
    """Per-S1 F0.5 vector (len n_s1); singletons score 1 iff nothing predicted."""
    pred_i1 = np.asarray(pred_i1)
    pred_y = np.asarray(pred_y, dtype=np.float64)
    n_true = np.asarray(n_true)
    n_pred = np.bincount(pred_i1, minlength=n_s1).astype(np.float64)
    tp = np.bincount(pred_i1, weights=pred_y, minlength=n_s1)
    with np.errstate(divide="ignore", invalid="ignore"):
        P = np.where(n_pred > 0, tp / n_pred, 0.0)
        R = np.where(n_true > 0, tp / np.maximum(n_true, 1), 0.0)
        f = np.where(tp > 0, 1.25 * P * R / (0.25 * P + R), 0.0)
    return np.where(n_true == 0, (n_pred == 0).astype(float), f)


def macro_f05(pred_i1, pred_y, n_true, n_s1):
    """pred_i1: S1 index per predicted pair; pred_y: 1 if the pair is true; n_true: true
    matches per S1 (array over all n_s1 entities). Singletons score 1 iff nothing predicted."""
    return float(f05_per_entity(pred_i1, pred_y, n_true, n_s1).mean())


# ----------------------------------------------------------------------------- tuning
def _countries(a):
    return np.asarray(pd.Series(a).astype(str).to_numpy(dtype=object))


def tune_per_country(d, y_pair, n_true, country_of_s1, n_s1):
    """Grid-search (thr, ratio) maximising macro F0.5 per country and globally.

    d: decode table (i1, i2, p, best); y_pair: truth per row of d; n_true: true matches per
    S1 (len n_s1); country_of_s1: country per S1 (len n_s1). Returns
    {country: (thr, ratio), '__global__': (thr, ratio)}; a country's score is the mean
    of the per-entity F0.5 restricted to its own S1 entities.
    """
    y_pair = np.asarray(y_pair, dtype=np.float64)
    n_true = np.asarray(n_true)
    i1 = d.i1.to_numpy()
    p, best = d.p.to_numpy(), d.best.to_numpy()
    cs = _countries(country_of_s1)
    masks = {c: cs == c for c in np.unique(cs)}
    masks[GLOBAL] = np.ones(n_s1, dtype=bool)
    best_score = {c: -1.0 for c in masks}
    table = {c: (0.5, 0.0) for c in masks}
    for ratio in RATIOS:
        for thr in THRS:
            m = (p >= thr) & (p >= ratio * best)
            f = f05_per_entity(i1[m], y_pair[m], n_true, n_s1)
            for c, cm in masks.items():
                s = float(f[cm].mean())
                if s > best_score[c]:
                    best_score[c], table[c] = s, (float(thr), float(ratio))
    for c in table:
        log(f"tune {c}: n_s1={int(masks[c].sum()):,} macro F0.5={best_score[c]:.4f} "
            f"at thr={table[c][0]:.3f} ratio={table[c][1]}")
    return table


def _lookup(country_array, table, pos):
    cs = _countries(country_array)
    out = np.full(len(cs), float(table[GLOBAL][pos]), dtype=np.float32)
    for c in np.unique(cs):
        if c in table and c != GLOBAL:
            out[cs == c] = float(table[c][pos])
    return out


def thresholds_for(country_array, table):
    """thr per element of `country_array` (fallback '__global__'); float32 array."""
    return _lookup(country_array, table, 0)


def ratios_for(country_array, table):
    """ratio per element of `country_array` (fallback '__global__'); float32 array."""
    return _lookup(country_array, table, 1)


def decide_by_country(d, country_of_s1, table):
    """decide() with per-country (thr, ratio) looked up through the S1 index of each row."""
    c_rows = _countries(country_of_s1)[d.i1.to_numpy()]
    return decide(d, thresholds_for(c_rows, table), ratios_for(c_rows, table))


def score_breakdown(d, y_pair, n_true, country_of_s1, table):
    """Log per-country macro F0.5, singleton accuracy and false-merge rate after decoding
    `d` with `table`; returns {country: dict(f05, singleton_acc, false_merge, n_s1)}."""
    y_pair = np.asarray(y_pair, dtype=np.float64)
    n_true = np.asarray(n_true)
    n_s1 = len(n_true)
    cs = _countries(country_of_s1)
    c_rows = cs[d.i1.to_numpy()]
    m = _mask(d, thresholds_for(c_rows, table), ratios_for(c_rows, table))
    ki1, ky = d.i1.to_numpy()[m], y_pair[m]
    f = f05_per_entity(ki1, ky, n_true, n_s1)
    n_pred = np.bincount(ki1, minlength=n_s1)
    n_false = np.bincount(ki1, weights=1.0 - ky, minlength=n_s1)
    out = {}
    for c in list(np.unique(cs)) + [GLOBAL]:
        cm = np.ones(n_s1, dtype=bool) if c == GLOBAL else cs == c
        single = cm & (n_true == 0)
        r = dict(
            n_s1=int(cm.sum()),
            f05=float(f[cm].mean()) if cm.any() else float("nan"),
            singleton_acc=float((n_pred[single] == 0).mean()) if single.any() else float("nan"),
            false_merge=float(n_false[cm].sum() / max(n_pred[cm].sum(), 1)),
            s1_with_false=float((n_false[cm] > 0).mean()) if cm.any() else float("nan"),
        )
        out[c] = r
        log(f"score {c}: n_s1={r['n_s1']:,} F0.5={r['f05']:.4f} singleton_acc={r['singleton_acc']:.4f} "
            f"false_merge(pairs)={r['false_merge']:.4f} s1_with_false={r['s1_with_false']:.4f} "
            f"pred/S1={n_pred[cm].mean():.2f} true/S1={n_true[cm].mean():.2f}")
    return out
