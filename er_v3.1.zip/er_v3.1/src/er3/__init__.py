"""er3: standalone v3 pipeline for the Amazon ML Challenge Business Entity Resolution.

Stages (see er3.pipeline): prep -> finetune-embed -> embed -> block -> features ->
train -> crossenc -> tune -> test. Hash-key blocking and hand-crafted features come
from v2; v3 adds a fine-tuned multilingual bi-encoder (ANN candidates + cosine
features) and a cross-encoder rescoring the uncertain probability band.
"""
__version__ = "3.1.0"
