"""Pairwise features for candidate pairs, computed on chunks of pairs (adapted from v2).

String similarities use rapidfuzz's multithreaded element-wise `cpdist`; the remaining
features are vectorised with numpy. Context features (gap to the best candidate of the
same S1, rank, candidate count) are computed within the chunk, so chunks must contain
complete S1 groups (the caller splits by i1 ranges).

v3 adds the neural columns that the blocking stage already attaches to the pairs frame
(ann_sim, ann_rank, emb_cos) and their within-S1-group context (gap_emb, rank_emb).
"""
import numpy as np
import pandas as pd
from rapidfuzz import fuzz, process
from rapidfuzz.distance import JaroWinkler

V2_FEATURES = ["n_keys", "n_ratio", "n_tsort", "n_tset", "n_partial", "n_jw", "a_tset", "a_ratio", "a_partial",
               "postal_state", "house_state", "house_rel", "num_overlap", "num_conflict", "len_l", "len_r", "alen_l", "alen_r",
               "addr_empty_r", "is_s3", "non_ascii_r", "ntok_l", "ntok_r", "prefix_eq",
               "legal_rel", "legal_l", "legal_r",
               "gap_ntset", "gap_atset", "gap_nratio", "rank1", "n_cand1"]
EMB_FEATURES = ["ann_sim", "ann_rank", "emb_cos", "gap_emb", "rank_emb"]
FEATURES = V2_FEATURES + EMB_FEATURES

# defaults used when the pairs frame lacks the neural columns (--no-embed runs)
ANN_SIM_NONE = -1.0
ANN_RANK_NONE = 127
EMB_COS_NONE = -1.0


# legal-form relation between the two names: the generator's hard negatives SWAP the legal
# form (Inc -> Co, LLC -> Corp); true variants keep, drop or abbreviate it
_LEGAL_ID = {k: i + 1 for i, k in enumerate(["pvtltd", "pvt", "ltd", "llc", "llp", "inc", "corp", "co",
                                                 "pllc", "pc", "plc", "sarl", "sasu", "sas", "eurl", "gmbh"])}
_ABBREV_GROUPS = ({"pvtltd", "pvt", "ltd"}, {"co", "corp"}, {"llc", "pllc"})


def _legal_rel(a, b):
    if a == b:
        return 1 if a else 0            # same / none
    if not a or not b:
        return 2                        # dropped on one side
    if any({a, b} <= g for g in _ABBREV_GROUPS):
        return 3                        # abbreviation of the same form
    return 4                            # swapped


def _house_rel(a, b):
    if not a or not b:
        return 0                        # missing
    if a == b:
        return 1
    da, db = "".join(c for c in a if c.isdigit()), "".join(c for c in b if c.isdigit())
    if da == db:
        return 2                        # same digits, different separators
    if da.lstrip("0") == db.lstrip("0"):
        return 3                        # leading zeros
    if da and db and (da in db or db in da):
        return 4                        # substring (dropped / added digit)
    if len(da) == len(db) and sum(x != y for x, y in zip(da, db)) == 1:
        return 5                        # one digit changed
    return 6                            # different


def _cp(a, b, scorer, workers):
    return process.cpdist(a, b, scorer=scorer, workers=workers, dtype=np.float32)


def _obj(frame, col, idx):
    """Column `col` of `frame` (pyarrow strings allowed) gathered at `idx` as an object array.

    Gathers first (positional `take`) and converts only the gathered rows, so a 10M-row
    pool column is never turned into 10M python strings for every feature chunk."""
    return frame[col].take(np.asarray(idx)).to_numpy(dtype=object)


def _tri(l, r):
    l, r = np.asarray(l, dtype=object), np.asarray(r, dtype=object)
    empty = (l == "") | (r == "")
    return np.where(empty, 0, np.where(l == r, 1, -1)).astype(np.int8)


def _num_feats(nl, nr):
    ov = np.empty(len(nl), dtype=np.float32)
    cf = np.zeros(len(nl), dtype=np.int8)
    for k, (a, b) in enumerate(zip(nl, nr)):
        if a and b:
            sa, sb = set(a.split()), set(b.split())
            inter = len(sa & sb)
            ov[k] = inter / len(sa | sb)
            cf[k] = inter == 0
        else:
            ov[k] = -1
    return ov, cf


def _col(pairs, name, default, dtype):
    """pairs[name] cast to dtype, or a constant column when the frame lacks it."""
    if name in pairs.columns:
        return pairs[name].to_numpy().astype(dtype, copy=False)
    return np.full(len(pairs), default, dtype=dtype)


def features(pairs, s1, other, workers=4):
    """pairs: DataFrame(i1, i2, n_keys[, ann_sim, ann_rank, emb_cos]) -> DataFrame[FEATURES] (same row order)."""
    i1, i2 = pairs.i1.to_numpy(), pairs.i2.to_numpy()
    ln = _obj(s1, "name_c", i1).tolist()
    rn = _obj(other, "name_c", i2).tolist()
    la = _obj(s1, "addr_c", i1).tolist()
    ra = _obj(other, "addr_c", i2).tolist()
    f = pd.DataFrame({"n_keys": pairs.n_keys.to_numpy().astype(np.int8, copy=False)})
    f["n_ratio"] = _cp(ln, rn, fuzz.ratio, workers)
    f["n_tsort"] = _cp(ln, rn, fuzz.token_sort_ratio, workers)
    f["n_tset"] = _cp(ln, rn, fuzz.token_set_ratio, workers)
    f["n_partial"] = _cp(ln, rn, fuzz.partial_ratio, workers)
    f["n_jw"] = _cp(ln, rn, JaroWinkler.normalized_similarity, workers)
    f["a_tset"] = _cp(la, ra, fuzz.token_set_ratio, workers)
    f["a_ratio"] = _cp(la, ra, fuzz.ratio, workers)
    f["a_partial"] = _cp(la, ra, fuzz.partial_ratio, workers)
    f["postal_state"] = _tri(_obj(s1, "postal", i1), _obj(other, "postal", i2))
    lh, rh = _obj(s1, "house", i1), _obj(other, "house", i2)
    f["house_state"] = _tri(lh, rh)
    f["house_rel"] = np.fromiter((_house_rel(a, b) for a, b in zip(lh, rh)), np.int8, len(lh))
    ll, rl = _obj(s1, "legal", i1), _obj(other, "legal", i2)
    f["legal_rel"] = np.fromiter((_legal_rel(a, b) for a, b in zip(ll, rl)), np.int8, len(ll))
    f["legal_l"] = np.fromiter((_LEGAL_ID.get(a, 0) for a in ll), np.int8, len(ll))
    f["legal_r"] = np.fromiter((_LEGAL_ID.get(b, 0) for b in rl), np.int8, len(rl))
    ov, cf = _num_feats(_obj(s1, "nums", i1).tolist(), _obj(other, "nums", i2).tolist())
    f["num_overlap"], f["num_conflict"] = ov, cf
    f["len_l"] = np.fromiter((len(x) for x in ln), np.int16, len(ln))
    f["len_r"] = np.fromiter((len(x) for x in rn), np.int16, len(rn))
    f["alen_l"] = np.fromiter((len(x) for x in la), np.int16, len(la))
    f["alen_r"] = np.fromiter((len(x) for x in ra), np.int16, len(ra))
    f["addr_empty_r"] = (f.alen_r == 0).astype(np.int8)
    f["is_s3"] = (_obj(other, "src", i2) == "S3").astype(np.int8)
    f["non_ascii_r"] = other.non_ascii.to_numpy()[i2].astype(np.int8, copy=False)
    f["ntok_l"] = np.fromiter((x.count(" ") + 1 for x in ln), np.int8, len(ln))
    f["ntok_r"] = np.fromiter((x.count(" ") + 1 for x in rn), np.int8, len(rn))
    f["prefix_eq"] = np.fromiter((a.replace(" ", "")[:6] == b.replace(" ", "")[:6] for a, b in zip(ln, rn)),
                                 np.int8, len(ln))
    # neural columns attached by the blocking stage (pass-through, cast to compact dtypes)
    f["ann_sim"] = _col(pairs, "ann_sim", ANN_SIM_NONE, np.float32)
    f["ann_rank"] = _col(pairs, "ann_rank", ANN_RANK_NONE, np.int8)
    f["emb_cos"] = _col(pairs, "emb_cos", EMB_COS_NONE, np.float32)
    # context within the S1 group (chunks hold complete i1 groups)
    g = f.groupby(i1, sort=False)
    f["gap_ntset"] = f.n_tset - g.n_tset.transform("max")
    f["gap_atset"] = f.a_tset - g.a_tset.transform("max")
    f["gap_nratio"] = f.n_ratio - g.n_ratio.transform("max")
    f["rank1"] = g.n_tset.rank(ascending=False, method="first").astype(np.int16)
    f["n_cand1"] = g.n_tset.transform("size").astype(np.int32)
    f["gap_emb"] = (f.emb_cos - g.emb_cos.transform("max")).astype(np.float32)
    f["rank_emb"] = g.emb_cos.rank(ascending=False, method="first").astype(np.int16)
    return f[FEATURES]
