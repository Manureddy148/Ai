"""Bi-encoder embedding, ANN top-k blocking and pair cosine for er3.

All heavy work is chunked: embeddings live in float16 ``.npy`` memmaps on disk,
ANN search streams the pool through the device in ``p_block`` slices and
keeps a running top-k per query block, ``pair_cosine`` reads the memmaps in
blocks of pairs.

Example (tiny, CPU)::

    >>> model = load_encoder(tiny_dir, 'cpu')
    >>> encode_to_memmap(['a | x', 'b | y'], model, '/tmp/q.npy', device='cpu')
    >>> encode_to_memmap(['a | x', 'c | z', 'b | y'], model, '/tmp/p.npy', device='cpu')
    >>> idx, sim = ann_topk('/tmp/q.npy', '/tmp/p.npy',
    ...                     np.array(['us', 'us']), np.array(['us', 'us', 'in']), k=2)
    >>> idx.shape, sim.dtype
    ((2, 2), dtype('float16'))
    >>> pair_cosine('/tmp/q.npy', '/tmp/p.npy', np.array([0, 1]), np.array([0, 2]))
    array([1., 1.], dtype=float32)
"""
from __future__ import annotations

import json
import os

import numpy as np

from .log import log

PROGRESS_EVERY = 50_000


# ----------------------------------------------------------------------------
# encoder / memmap helpers
# ----------------------------------------------------------------------------
def load_encoder(model_path_or_name, device='cpu'):
    """Load a SentenceTransformer from a local dir or HF name onto ``device``."""
    from sentence_transformers import SentenceTransformer
    model = SentenceTransformer(str(model_path_or_name), device=device)
    return model


def _shape_path(out_path):
    return str(out_path) + '.shape.json'


def _progress_path(out_path):
    return str(out_path) + '.progress'


def _read_progress(out_path):
    try:
        with open(_progress_path(out_path)) as f:
            return int(f.read().strip() or 0)
    except (OSError, ValueError):
        return 0


def _write_progress(out_path, n):
    with open(_progress_path(out_path), 'w') as f:
        f.write(str(int(n)))


def _write_shape(out_path, n, dim):
    with open(_shape_path(out_path), 'w') as f:
        json.dump({'shape': [int(n), int(dim)], 'dtype': 'float16'}, f)


def open_memmap(out_path):
    """Open an existing float16 embedding memmap (read-only)."""
    return np.load(str(out_path), mmap_mode='r')


def encode_to_memmap(texts, model, out_path, batch_size=256, max_len=64,
                     device='cpu', prefix='query: '):
    """Encode ``texts`` (sequence / pandas Series of str) into a float16 memmap.

    Writes ``out_path`` (.npy, shape [n, dim], L2-normalised rows) plus
    ``out_path + '.shape.json'``. Progress is written every 50k rows so an
    interrupted run resumes from the last flushed row group. Returns the
    memmap opened read-only.
    """
    out_path = str(out_path)
    n = len(texts)
    # sentence-transformers >= 6 renamed the accessor; support both.
    get_dim = getattr(model, 'get_embedding_dimension', None) or model.get_sentence_embedding_dimension
    dim = int(get_dim())
    try:
        model.max_seq_length = int(max_len)
    except Exception:  # noqa: BLE001 - some models forbid the setter
        pass

    start = 0
    done_shape = None
    if os.path.exists(out_path) and os.path.exists(_shape_path(out_path)):
        try:
            with open(_shape_path(out_path)) as f:
                done_shape = tuple(json.load(f)['shape'])
        except (OSError, ValueError, KeyError):
            done_shape = None
    if done_shape == (n, dim):
        start = min(_read_progress(out_path), n)
        if start >= n:
            log(f'embed: {out_path} complete ({n}x{dim}), skipping')
            return open_memmap(out_path)
        mm = np.lib.format.open_memmap(out_path, mode='r+')
        if mm.shape != (n, dim) or mm.dtype != np.float16:
            del mm
            mm = np.lib.format.open_memmap(out_path, mode='w+', dtype=np.float16, shape=(n, dim))
            start = 0
        else:
            log(f'embed: resuming {out_path} at row {start}/{n}')
    else:
        mm = np.lib.format.open_memmap(out_path, mode='w+', dtype=np.float16, shape=(n, dim))
        _write_shape(out_path, n, dim)
        _write_progress(out_path, 0)

    # process in groups of batches so we flush/progress at bounded intervals
    group = max(int(batch_size) * 32, PROGRESS_EVERY)
    group = (group // int(batch_size)) * int(batch_size) or int(batch_size)
    prefix = prefix or ''
    is_series = hasattr(texts, 'iloc')
    next_log = start
    pos = start
    import torch
    use_amp = str(device).startswith('cuda')      # fp16 autocast on GPU only (output is fp16 anyway)
    while pos < n:
        end = min(pos + group, n)
        chunk = texts.iloc[pos:end] if is_series else texts[pos:end]
        chunk = [prefix + (str(t) if t is not None else '') for t in chunk]
        with torch.inference_mode(), torch.autocast(device_type='cuda', dtype=torch.float16, enabled=use_amp):
            emb = model.encode(chunk, batch_size=int(batch_size), convert_to_numpy=True,
                               normalize_embeddings=True, show_progress_bar=False,
                               device=device)
        mm[pos:end] = np.asarray(emb).astype(np.float16, copy=False)
        mm.flush()
        pos = end
        _write_progress(out_path, pos)
        if pos >= next_log:
            log(f'embed: {pos}/{n} rows -> {os.path.basename(out_path)}')
            next_log += max(PROGRESS_EVERY * 4, group)
    mm.flush()
    del mm
    _write_shape(out_path, n, dim)
    _write_progress(out_path, n)
    log(f'embed: done {n}x{dim} -> {out_path}')
    return open_memmap(out_path)


# ----------------------------------------------------------------------------
# ANN top-k (chunked torch matmul, no faiss)
# ----------------------------------------------------------------------------
def _as_np_str(a):
    a = np.asarray(a)
    if a.dtype.kind not in ('U', 'S', 'O'):
        a = a.astype(object)
    return a


Q_RESIDENT_BYTES = 3 << 30   # keep all queries of a country on the device below this size


def _topk_country(q_mm, p_mm, q_rows, p_rows, k, device, q_block, p_block, torch):
    """Top-k pool rows (global indices) for each query row within one country.

    The pool is streamed through the device ONCE (outer loop over ``p_block``
    slices); the queries stay resident on the device (when they fit in
    ``Q_RESIDENT_BYTES``, e.g. 1.73M x 384 fp16 = 1.3 GB) and a running top-k
    per query is kept on the device. With the loops the other way round the
    10M-row pool memmap would be re-read once per query block (thousands of
    passes over 7.7 GB).
    """
    nq, npool = len(q_rows), len(p_rows)
    kk = min(k, npool)
    out_idx = np.full((nq, k), -1, dtype=np.int32)
    out_sim = np.full((nq, k), -1.0, dtype=np.float16)
    if kk == 0 or nq == 0:
        return out_idx, out_sim
    is_cuda = str(device).startswith('cuda')
    dt = torch.float16 if is_cuda else torch.float32
    dev = torch.device(str(device))
    q_sorted = np.sort(q_rows)            # sorted -> sequential memmap reads
    p_sorted = np.sort(p_rows)
    q_inv = np.argsort(np.argsort(q_rows)) if not np.array_equal(q_sorted, q_rows) else None
    dim = int(q_mm.shape[1])
    resident = nq * dim * (2 if is_cuda else 4) <= Q_RESIDENT_BYTES
    q_dev = (torch.from_numpy(np.ascontiguousarray(q_mm[q_sorted])).to(device=dev, dtype=dt)
             if resident else None)
    best_sim = torch.full((nq, kk), float('-inf'), device=dev, dtype=dt)
    best_idx = torch.full((nq, kk), -1, device=dev, dtype=torch.int64)
    n_pblocks = (npool + p_block - 1) // p_block
    for pb_no, ps in enumerate(range(0, npool, p_block)):
        pe = min(ps + p_block, npool)
        p_glob = p_sorted[ps:pe]
        p = torch.from_numpy(np.ascontiguousarray(p_mm[p_glob])).to(device=dev, dtype=dt)
        g_all = torch.from_numpy(p_glob.astype(np.int64)).to(dev)
        kb = min(kk, pe - ps)
        for qs in range(0, nq, q_block):
            qe = min(qs + q_block, nq)
            if resident:
                q = q_dev[qs:qe]
            else:
                q = torch.from_numpy(np.ascontiguousarray(q_mm[q_sorted[qs:qe]])).to(device=dev, dtype=dt)
            sims = q @ p.T                                       # [qb, pb]
            s, i = torch.topk(sims, kb, dim=1)
            del sims
            cat_s = torch.cat([best_sim[qs:qe], s], dim=1)
            cat_i = torch.cat([best_idx[qs:qe], g_all[i]], dim=1)
            bs, sel = torch.topk(cat_s, kk, dim=1)
            best_sim[qs:qe] = bs
            best_idx[qs:qe] = torch.gather(cat_i, 1, sel)
            del cat_s, cat_i, s, i, bs, sel, q
        del p, g_all
        if n_pblocks > 1:
            log(f'ann:   pool block {pb_no + 1}/{n_pblocks} ({pe:,}/{npool:,} rows) done for {nq:,} queries')
    bs = best_sim.float().cpu().numpy()
    bi = best_idx.cpu().numpy()
    valid = bi >= 0
    out_idx[:, :kk] = np.where(valid, bi, -1).astype(np.int32)
    out_sim[:, :kk] = np.where(valid, bs, -1.0).astype(np.float16)
    del q_dev, best_sim, best_idx
    if q_inv is not None:  # restore caller's query order
        out_idx = out_idx[q_inv]
        out_sim = out_sim[q_inv]
    return out_idx, out_sim


def ann_topk(q_path, p_path, q_country, p_country, k=20, device='cpu',
             q_block=4096, p_block=500_000):
    """Cosine top-k pool neighbours for every query, restricted to same country.

    Returns ``(idx int32 [nq, k], sim float16 [nq, k])`` with global pool row
    indices; entries are ``-1`` / ``-1.0`` where a country has fewer than
    ``k`` pool rows (or no pool rows at all). Embeddings are assumed to be
    L2-normalised (as written by :func:`encode_to_memmap`).
    """
    import torch
    q_mm = open_memmap(q_path)
    p_mm = open_memmap(p_path)
    q_country = _as_np_str(q_country)
    p_country = _as_np_str(p_country)
    nq = q_mm.shape[0]
    if len(q_country) != nq or len(p_country) != p_mm.shape[0]:
        raise ValueError('country arrays must align with the embedding memmaps')
    if device != 'cpu' and not torch.cuda.is_available():
        device = 'cpu'
    idx = np.full((nq, k), -1, dtype=np.int32)
    sim = np.full((nq, k), -1.0, dtype=np.float16)
    countries = np.unique(q_country)
    with torch.inference_mode():
        for c in countries:
            q_rows = np.flatnonzero(q_country == c)
            p_rows = np.flatnonzero(p_country == c)
            log(f'ann: country={str(c)!r} queries={len(q_rows)} pool={len(p_rows)} k={k}')
            if len(p_rows) == 0:
                continue
            ci, cs = _topk_country(q_mm, p_mm, q_rows, p_rows, k, device,
                                   int(q_block), int(p_block), torch)
            idx[q_rows] = ci
            sim[q_rows] = cs
    del q_mm, p_mm
    return idx, sim


# ----------------------------------------------------------------------------
# pairwise cosine from the memmaps
# ----------------------------------------------------------------------------
def pair_cosine(q_path, p_path, i1, i2, block=2_000_000):
    """Row-wise cosine ``q[i1] . p[i2]`` (float32) computed in blocks of pairs."""
    q_mm = open_memmap(q_path)
    p_mm = open_memmap(p_path)
    i1 = np.asarray(i1)
    i2 = np.asarray(i2)
    n = len(i1)
    out = np.empty(n, dtype=np.float32)
    for s in range(0, n, int(block)):
        e = min(s + int(block), n)
        a = q_mm[i1[s:e]].astype(np.float32, copy=False)
        b = p_mm[i2[s:e]].astype(np.float32, copy=False)
        out[s:e] = np.einsum('ij,ij->i', a, b)
    del q_mm, p_mm
    return out
