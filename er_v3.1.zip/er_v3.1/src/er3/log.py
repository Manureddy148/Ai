"""Minimal timestamped logger; T0 is the only global state in the package."""
import sys
import time

T0 = time.time()


def log(msg):
    """Print `msg` prefixed with the seconds elapsed since import (flushed, stdout)."""
    sys.stdout.write(f"[{time.time() - T0:8.1f}s] {msg}\n")
    sys.stdout.flush()
