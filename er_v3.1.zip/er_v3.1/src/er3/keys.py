"""Hash-key blocking (adapted from v2 blocking.py).

Candidate pairs are S1 x S2/S3 records that share at least one key. Keys are strings
built from the normalised fields (always prefixed with the country so records never
pair across countries), hashed to int64 and joined with numpy. Keys shared by more
than `cap` S2/S3 records are dropped (no discriminative power, would explode the pair
count). The number of distinct keys a pair shares is returned as a feature (`n_keys`).
In v3 these pairs are unioned with ANN candidates in the pipeline's block stage.
"""
import numpy as np
import pandas as pd

from .log import log

PAIR_COLS = {"i1": np.int32, "i2": np.int32, "n_keys": np.int8}


def _keys_for(name_c, addr_c, house, country):
    """All blocking keys of one record (list of strings)."""
    c = country
    toks = name_c.split()
    keys = []
    if toks:
        keys.append(f"n2|{c}|{' '.join(toks[:2])}")
        keys.append(f"np|{c}|{name_c.replace(' ', '')[:8]}")
        if len(toks) >= 2:
            keys.append("ns|" + c + "|" + "|".join(sorted(t[:4] for t in toks)[:3]))
    atoks = addr_c.split()
    alpha = [t for t in atoks if t.isalpha() and len(t) > 2]
    if house:
        hd = house.lstrip("0") or house          # '001909' and '1909' share a key
        # house number + the first purely alphabetic token after it (street / area)
        after = False
        street = ""
        for t in atoks:
            if after and t.isalpha() and len(t) > 2:
                street = t
                break
            if t == house:
                after = True
        if street:
            keys.append(f"ah|{c}|{hd}|{street}")
        # house number + each of the last two alphabetic tokens (city / state)
        for t in alpha[-2:]:
            keys.append(f"al|{c}|{hd}|{t}")
        if toks:
            keys.append(f"nh|{c}|{toks[0]}|{hd}")
    elif atoks and toks:
        # no house number: name token + first address token
        keys.append(f"na|{c}|{toks[0]}|{atoks[0]}")
    # house-number-free address keys (the generator perturbs house numbers): street + locality
    if len(alpha) >= 2:
        keys.append(f"sa|{c}|{alpha[0]}|{alpha[1]}")
        keys.append(f"sl|{c}|{alpha[0]}|{alpha[-1]}")
        if toks:
            keys.append(f"ns|{c}|{toks[0]}|{alpha[0]}")
    return keys


def _obj(col):
    """Object array of python str with missing values as '' (works for pyarrow strings)."""
    return col.fillna("").astype(object).to_numpy(dtype=object)


def key_table(frame, chunk=500_000):
    """(hash int64, row int32) arrays for every key of every record of `frame`."""
    hs, rows = [], []
    name_c, addr_c, house, country = (_obj(frame.name_c), _obj(frame.addr_c),
                                      _obj(frame.house), _obj(frame.country))
    for s in range(0, len(frame), chunk):
        ks, rs = [], []
        for i in range(s, min(s + chunk, len(frame))):
            k = _keys_for(name_c[i], addr_c[i], house[i], country[i])
            ks.extend(k)
            rs.extend([i] * len(k))
        if ks:
            hs.append(pd.util.hash_array(np.array(ks, dtype=object)).astype(np.int64))
            rows.append(np.asarray(rs, dtype=np.int32))
    if not hs:
        return np.array([], np.int64), np.array([], np.int32)
    return np.concatenate(hs), np.concatenate(rows)


def pool_index(other, cap=150):
    """Sorted (hash int64, row int32) key index of the S2/S3 pool, over-populated keys removed."""
    h2, r2 = key_table(other)
    uniq, inv, cnt = np.unique(h2, return_inverse=True, return_counts=True)
    keep = cnt[inv] <= cap
    log(f"keys: {len(h2):,} S2/S3 keys, {len(uniq):,} distinct, "
        f"{(cnt > cap).sum():,} keys over cap={cap} dropped ({(~keep).sum():,} rows)")
    del uniq, inv, cnt
    h2, r2 = h2[keep], r2[keep]
    order = np.argsort(h2, kind="stable")
    return h2[order], r2[order]


def empty_pairs():
    """Empty DataFrame[i1, i2, n_keys] with the canonical dtypes."""
    return pd.DataFrame({c: np.array([], dt) for c, dt in PAIR_COLS.items()})


def block_chunks(s1, index, s1_chunk=100_000):
    """Yield DataFrames (i1 int32, i2 int32, n_keys int8) of candidate pairs, one per
    chunk of S1 rows (i1 is the position in `s1`; chunks arrive in increasing i1 order,
    sorted by (i1, i2) within a chunk). Chunks with no candidates are skipped. Memory is
    bounded by the chunk size, not by the total pair count."""
    h2, r2 = index
    for s in range(0, len(s1), s1_chunk):
        sub = s1.iloc[s:s + s1_chunk]
        hh, rr = key_table(sub)
        if len(hh) == 0:
            continue
        lo = np.searchsorted(h2, hh, side="left")
        hi = np.searchsorted(h2, hh, side="right")
        n = hi - lo
        has = n > 0
        if not has.any():
            continue
        lo, n, rr = lo[has], n[has], rr[has]
        # expand ranges: for each S1 key, the S2/S3 rows sharing it
        rep_i1 = np.repeat(rr.astype(np.int64) + s, n)
        offsets = np.arange(n.sum()) - np.repeat(np.cumsum(n) - n, n)
        idx2 = r2[np.repeat(lo, n) + offsets].astype(np.int64)
        code = rep_i1 * (1 << 32) + idx2
        del rep_i1, idx2, offsets
        uniq, cnt = np.unique(code, return_counts=True)
        yield pd.DataFrame({"i1": (uniq >> 32).astype(np.int32), "i2": (uniq & 0xFFFFFFFF).astype(np.int32),
                            "n_keys": np.minimum(cnt, 127).astype(np.int8)})


def block(s1, other, cap=150, s1_chunk=100_000):
    """All hash-key candidate pairs (i1, i2, n_keys) of `s1` against `other` (prepped frames)."""
    parts = list(block_chunks(s1, pool_index(other, cap), s1_chunk))
    out = pd.concat(parts, ignore_index=True) if parts else empty_pairs()
    log(f"keys: {len(out):,} candidate pairs for {len(s1):,} S1 ({len(out) / max(len(s1), 1):.1f} per S1); "
        f"S1 with >=1 candidate: {out.i1.nunique():,}")
    return out
