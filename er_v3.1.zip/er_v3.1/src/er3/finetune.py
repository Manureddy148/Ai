"""Fine-tuning of the bi-encoder (embedding) and cross-encoder (rescoring) models.

Both trainers are explicit torch loops over sentence-transformers primitives
(``SentenceTransformer.tokenize``/forward with its MultipleNegativesRankingLoss
module; ``CrossEncoder.model``/``tokenizer`` with BCE-with-logits), so the same
code runs on a Kaggle GPU with fp16 autocast and on a CPU with the locally
built tiny models of ``er3.tiny`` -- no ``datasets`` dependency, no legacy
``fit`` path.

* ``build_pair_texts``: (S1 text, matched S2/S3 text) pairs from the train
  ground truth; text = ``f"{name_raw} | {addr_raw}"`` with the e5 ``query: ``
  prefix on both sides.
* ``finetune_biencoder``: MultipleNegativesRankingLoss (in-batch negatives).
* ``finetune_crossencoder``: binary cross-entropy on (text_a, text_b, label).

Nothing here touches the network at import time; a HF model name is only
resolved when a trainer is called with it.
"""
from __future__ import annotations

import os
import random

import numpy as np
import pandas as pd

from .log import log

SEP = " | "
LOG_EVERY = 200          # training steps between progress log lines
CPU_MAX_BATCH = 32       # batch size cap when training on CPU (tiny models / smoke test)


# ----------------------------------------------------------------------------
# text helpers
# ----------------------------------------------------------------------------
def record_text(name_raw, addr_raw):
    """Text fed to the neural encoders for one record: ``"{name} | {addr}"``."""
    return f"{name_raw}{SEP}{addr_raw}"


def record_texts(df, prefix=""):
    """List of ``record_text`` for every row of a prepped frame (name_raw/addr_raw)."""
    names = df["name_raw"].fillna("").astype(str).tolist()
    addrs = df["addr_raw"].fillna("").astype(str).tolist()
    return [prefix + record_text(n, a) for n, a in zip(names, addrs)]


def _gt_pairs(s1_ids, pool_ids, gt_df):
    """Row positions (i1, i2) of every ground-truth match present in both frames."""
    gt = gt_df[["source1_entity_id", "matched_entity_ids"]].copy()
    gt["matched_entity_ids"] = gt["matched_entity_ids"].fillna("").astype(str)
    gt = gt[gt["matched_entity_ids"].str.len() > 0]
    if len(gt) == 0:
        return np.zeros(0, np.int64), np.zeros(0, np.int64)
    lists = gt["matched_entity_ids"].str.split(",")
    sizes = lists.str.len().to_numpy()
    i1 = np.repeat(pd.Index(s1_ids).get_indexer(gt["source1_entity_id"]), sizes)
    flat = np.concatenate([np.asarray(x, dtype=object) for x in lists.tolist()])
    flat = pd.Series(flat).str.strip()
    i2 = pd.Index(pool_ids).get_indexer(flat)
    ok = (i1 >= 0) & (i2 >= 0)
    return i1[ok].astype(np.int64), i2[ok].astype(np.int64)


def build_pair_texts(s1_prepped, pool_prepped, gt_df, prefix="query: ",
                     max_pairs=None, seed=0):
    """(text_a, text_b) list for every S1 -> matched record pair of the ground truth.

    ``gt_df`` has columns ``source1_entity_id, matched_entity_ids`` (comma-joined).
    Pairs are shuffled and capped at ``max_pairs`` (None = keep all). Ids that are
    not present in the prepped frames are skipped.
    """
    i1, i2 = _gt_pairs(s1_prepped["entity_id"].to_numpy(), pool_prepped["entity_id"].to_numpy(), gt_df)
    n_all = len(i1)
    rng = np.random.default_rng(seed)
    order = rng.permutation(n_all)
    if max_pairs is not None and n_all > max_pairs:
        order = order[:max_pairs]
    i1, i2 = i1[order], i2[order]
    s1_sub = s1_prepped.iloc[i1]
    pool_sub = pool_prepped.iloc[i2]
    texts_a = record_texts(s1_sub, prefix)
    texts_b = record_texts(pool_sub, prefix)
    log(f"build_pair_texts: {n_all:,} ground-truth pairs, kept {len(texts_a):,} "
        f"({len(np.unique(i1)):,} distinct S1)")
    return list(zip(texts_a, texts_b))


def balance_triples(triples, max_n=None, seed=0):
    """Down-sample ``(a, b, label)`` triples to a 50/50 label mix, capped at ``max_n``."""
    rng = random.Random(seed)
    pos = [t for t in triples if float(t[2]) >= 0.5]
    neg = [t for t in triples if float(t[2]) < 0.5]
    n = min(len(pos), len(neg))
    if max_n is not None:
        n = min(n, max_n // 2)
    rng.shuffle(pos)
    rng.shuffle(neg)
    out = pos[:n] + neg[:n]
    rng.shuffle(out)
    log(f"balance_triples: {len(pos):,} pos / {len(neg):,} neg -> {len(out):,} balanced")
    return out


# ----------------------------------------------------------------------------
# training helpers
# ----------------------------------------------------------------------------
def _is_cuda(device):
    return str(device).startswith("cuda")


def _effective_batch(batch_size, device):
    if _is_cuda(device):
        return int(batch_size)
    return int(min(batch_size, CPU_MAX_BATCH))


def _batches(n, batch_size, rng):
    """Yield index arrays of a shuffled permutation of range(n), dropping a tail < 2."""
    order = rng.permutation(n)
    for s in range(0, n, batch_size):
        idx = order[s:s + batch_size]
        if len(idx) >= 2:
            yield idx


def _run_epochs(step_fn, params, n, batch_size, epochs, lr, use_amp, device, tag, seed, threads=None):
    """Generic AdamW + linear warmup/decay loop; ``step_fn(idx) -> loss tensor``.

    On CPU the torch intra-op thread count is capped at ``threads`` for the
    duration of training (oversubscribed containers are ~50x slower) and
    restored afterwards.
    """
    import torch
    from transformers import get_linear_schedule_with_warmup

    prev_threads = torch.get_num_threads()
    if not _is_cuda(device) and threads:
        torch.set_num_threads(max(1, min(prev_threads, int(threads))))
    try:
        return _train_loop(step_fn, params, n, batch_size, epochs, lr, use_amp, tag, seed,
                           torch, get_linear_schedule_with_warmup)
    finally:
        torch.set_num_threads(prev_threads)


def _grad_scaler(torch, enabled):
    """``torch.amp.GradScaler`` (torch >= 2.3) or the older ``torch.cuda.amp.GradScaler``."""
    amp = getattr(torch, "amp", None)
    if amp is not None and hasattr(amp, "GradScaler"):
        try:
            return amp.GradScaler("cuda", enabled=enabled)
        except TypeError:
            pass
    return torch.cuda.amp.GradScaler(enabled=enabled)


def _mnrl_loss_class():
    """MultipleNegativesRankingLoss across sentence-transformers layouts (3.x-5.x vs >= 6)."""
    try:
        from sentence_transformers.sentence_transformer.losses import MultipleNegativesRankingLoss
    except ImportError:
        from sentence_transformers.losses import MultipleNegativesRankingLoss
    return MultipleNegativesRankingLoss


def _train_loop(step_fn, params, n, batch_size, epochs, lr, use_amp, tag, seed, torch, get_sched):
    rng = np.random.default_rng(seed)
    steps_per_epoch = sum(1 for _ in _batches(n, batch_size, np.random.default_rng(0)))
    total = max(1, steps_per_epoch * max(1, epochs))
    opt = torch.optim.AdamW(params, lr=lr, weight_decay=0.01)
    sched = get_sched(opt, max(1, int(0.1 * total)), total)
    scaler = _grad_scaler(torch, use_amp)
    step, run_sum, run_cnt = 0, 0.0, 0
    for ep in range(max(1, epochs)):
        for idx in _batches(n, batch_size, rng):
            with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=use_amp):
                loss = step_fn(idx)
            opt.zero_grad(set_to_none=True)
            scaler.scale(loss).backward()
            scaler.unscale_(opt)
            torch.nn.utils.clip_grad_norm_(params, 1.0)
            scaler.step(opt)
            scaler.update()
            sched.step()
            step += 1
            run_sum += float(loss.detach())
            run_cnt += 1
            if step % LOG_EVERY == 0 or step == total:
                log(f"{tag}: epoch {ep + 1}/{max(1, epochs)} step {step:,}/{total:,} "
                    f"loss {run_sum / max(1, run_cnt):.4f} lr {sched.get_last_lr()[0]:.2e}")
                run_sum, run_cnt = 0.0, 0
    return step


def finetune_biencoder(pairs, base_model, out_dir, device="cpu", epochs=1, batch_size=128,
                       max_pairs=1_500_000, fp16=True, max_len=64, lr=2e-5, seed=0, threads=2):
    """Fine-tune a SentenceTransformer on (text_a, text_b) positive pairs with
    sentence-transformers' MultipleNegativesRankingLoss (in-batch negatives).

    Explicit torch loop (AdamW, 10% linear warmup, grad clip 1.0); fp16 autocast
    only on CUDA. Saves the model to ``out_dir`` (loadable with
    ``SentenceTransformer(out_dir)``) and returns ``out_dir``.
    """
    import torch
    from sentence_transformers import SentenceTransformer
    MultipleNegativesRankingLoss = _mnrl_loss_class()

    torch.manual_seed(seed)
    pairs = list(pairs)
    if max_pairs is not None and len(pairs) > max_pairs:
        random.Random(seed).shuffle(pairs)
        pairs = pairs[:max_pairs]
    bs = _effective_batch(batch_size, device)
    use_amp = bool(fp16 and _is_cuda(device))
    log(f"finetune_biencoder: base={base_model} pairs={len(pairs):,} device={device} "
        f"batch={bs} epochs={epochs} max_len={max_len} amp={use_amp}")

    model = SentenceTransformer(str(base_model), device=str(device))
    model.max_seq_length = int(max_len)
    model.train()
    loss_mod = MultipleNegativesRankingLoss(model)
    dev = torch.device(str(device))
    a_all = [a for a, _ in pairs]
    b_all = [b for _, b in pairs]

    # sentence-transformers >= 6 renamed tokenize -> preprocess (same output dict).
    featurize = getattr(model, 'preprocess', None) or model.tokenize

    def step_fn(idx):
        feats = []
        for col in (a_all, b_all):
            f = featurize([col[i] for i in idx])
            feats.append({k: (v.to(dev) if hasattr(v, 'to') else v) for k, v in f.items()})
        return loss_mod(feats, torch.zeros(len(idx), device=dev))

    params = [p for p in model.parameters() if p.requires_grad]
    n_steps = _run_epochs(step_fn, params, len(pairs), bs, epochs, lr, use_amp, device, "biencoder", seed, threads)
    model.eval()
    os.makedirs(out_dir, exist_ok=True)
    model.save(str(out_dir))
    log(f"finetune_biencoder: {n_steps:,} steps, saved -> {out_dir}")
    return str(out_dir)


def finetune_crossencoder(triples, base_model, out_dir, device="cpu", epochs=1, batch_size=32,
                          max_len=96, fp16=True, lr=2e-5, seed=0, threads=2):
    """Fine-tune a CrossEncoder (num_labels=1, BCE-with-logits) on
    ``(text_a, text_b, label)`` triples. Saves to ``out_dir`` (loadable with
    ``CrossEncoder(out_dir)``) and returns ``out_dir``.
    """
    import torch
    from sentence_transformers.cross_encoder import CrossEncoder

    torch.manual_seed(seed)
    triples = list(triples)
    bs = _effective_batch(batch_size, device)
    use_amp = bool(fp16 and _is_cuda(device))
    y_all = np.asarray([float(t[2]) for t in triples], dtype=np.float32)
    log(f"finetune_crossencoder: base={base_model} triples={len(triples):,} "
        f"(pos={int((y_all >= 0.5).sum()):,}) device={device} batch={bs} epochs={epochs} "
        f"max_len={max_len} amp={use_amp}")

    ce = CrossEncoder(str(base_model), num_labels=1, max_length=int(max_len), device=str(device))
    net, tok = ce.model, ce.tokenizer
    dev = torch.device(str(device))
    net.to(dev)
    net.train()
    bce = torch.nn.BCEWithLogitsLoss()
    a_all = [t[0] for t in triples]
    b_all = [t[1] for t in triples]
    y_t = torch.from_numpy(y_all)

    def step_fn(idx):
        enc = tok([a_all[i] for i in idx], [b_all[i] for i in idx], padding=True, truncation=True,
                  max_length=int(max_len), return_tensors="pt")
        enc = {k: v.to(dev) for k, v in enc.items()}
        logits = net(**enc).logits.view(-1).float()
        return bce(logits, y_t[idx].to(dev))

    params = [p for p in net.parameters() if p.requires_grad]
    n_steps = _run_epochs(step_fn, params, len(triples), bs, epochs, lr, use_amp, device, "crossenc", seed, threads)
    net.eval()
    os.makedirs(out_dir, exist_ok=True)
    ce.save(str(out_dir))
    log(f"finetune_crossencoder: {n_steps:,} steps, saved -> {out_dir}")
    return str(out_dir)
