"""LightGBM matcher, per-S1 decoding and vectorised macro-F0.5 scoring."""
import lightgbm as lgb
import numpy as np
import pandas as pd

from .log import log

PARAMS = dict(objective="binary", learning_rate=0.05, num_leaves=127, min_child_samples=100,
              feature_fraction=0.8, bagging_fraction=0.8, bagging_freq=1, lambda_l2=1.0,
              verbose=-1, n_jobs=4, seed=42)


def train(X, y, groups, rounds=3000, patience=100):
    """Train with an internal group-held-out early-stopping split (20% of S1 groups)."""
    rng = np.random.default_rng(0)
    g = np.unique(groups)
    hold = np.isin(groups, rng.choice(g, size=max(1, len(g) // 5), replace=False))
    Xa = np.ascontiguousarray(X.to_numpy(dtype=np.float32))
    dtr = lgb.Dataset(Xa[~hold], y[~hold], feature_name=list(X.columns), free_raw_data=True)
    dva = lgb.Dataset(Xa[hold], y[hold], feature_name=list(X.columns), reference=dtr, free_raw_data=True)
    m = lgb.train(PARAMS, dtr, rounds, valid_sets=[dva], callbacks=[lgb.early_stopping(patience, verbose=False)])
    log(f"model: best_iter={m.best_iteration}, train pairs={(~hold).sum():,}, holdout pairs={hold.sum():,}, "
        f"pos rate={y.mean():.4f}")
    imp = pd.Series(m.feature_importance("gain"), X.columns).sort_values(ascending=False)
    log("feature importance (gain, top 12): " + ", ".join(f"{k}={v:.0f}" for k, v in imp.head(12).items()))
    return m


def decode_table(i1, i2, p):
    """Assign each S2/S3 record to its best-scoring S1; record the best p per S1."""
    d = pd.DataFrame({"i1": i1, "i2": i2, "p": p.astype(np.float32)})
    d = d.sort_values("p", ascending=False, kind="stable").drop_duplicates("i2")
    d["best"] = d.groupby("i1").p.transform("max")
    return d.reset_index(drop=True)


def decide(d, thr, ratio):
    return d[(d.p >= thr) & (d.p >= ratio * d.best)]


def macro_f05(pred_i1, pred_y, n_true, n_s1):
    """pred_i1: S1 index per predicted pair; pred_y: 1 if the pair is true; n_true: true
    matches per S1 (array over all n_s1 entities). Singletons score 1 iff nothing predicted."""
    n_pred = np.bincount(pred_i1, minlength=n_s1).astype(np.float64)
    tp = np.bincount(pred_i1, weights=pred_y, minlength=n_s1)
    with np.errstate(divide="ignore", invalid="ignore"):
        P = np.where(n_pred > 0, tp / n_pred, 0.0)
        R = np.where(n_true > 0, tp / np.maximum(n_true, 1), 0.0)
        f = np.where(tp > 0, 1.25 * P * R / (0.25 * P + R), 0.0)
    f = np.where(n_true == 0, (n_pred == 0).astype(float), f)
    return float(f.mean())


def tune(d, y_pair, n_true, n_s1, mask_s1=None):
    """Grid-search (thr, ratio) on a decode table with truth labels; returns best triple.
    With mask_s1 (bool array over S1 entities) only those entities are scored."""
    best = (-1.0, 0.5, 0.0)
    p, bst, i1 = d.p.to_numpy(), d.best.to_numpy(), d.i1.to_numpy()
    if mask_s1 is not None:
        sel = mask_s1[i1]
        p, bst, i1, y_pair = p[sel], bst[sel], i1[sel], y_pair[sel]
        idx = np.flatnonzero(mask_s1)
        remap = np.full(n_s1, -1, np.int64); remap[idx] = np.arange(len(idx))
        i1, n_true, n_s1 = remap[i1], n_true[idx], len(idx)
    for ratio in (0.0, 0.5, 0.6, 0.7, 0.8, 0.9):
        for thr in np.arange(0.10, 0.96, 0.025):
            m = (p >= thr) & (p >= ratio * bst)
            s = macro_f05(i1[m], y_pair[m], n_true, n_s1)
            if s > best[0]:
                best = (s, float(thr), ratio)
    return best


def tune_per_country(d, y_pair, n_true, country_of_s1, n_s1):
    """{country: (thr, ratio, f05)} plus '__global__'; unseen countries use '__global__'."""
    table = {}
    s, thr, ratio = tune(d, y_pair, n_true, n_s1)
    table["__global__"] = (thr, ratio, s)
    log(f"tune: global macro F0.5={s:.4f} at thr={thr:.3f} ratio={ratio}")
    for c in np.unique(country_of_s1):
        mask = country_of_s1 == c
        if mask.sum() < 500:
            continue
        s, thr, ratio = tune(d, y_pair, n_true, n_s1, mask)
        table[str(c)] = (thr, ratio, s)
        log(f"tune: {c}: macro F0.5={s:.4f} at thr={thr:.3f} ratio={ratio} (n={mask.sum():,})")
    return table


def decide_by_country(d, country_of_s1, table):
    """Apply per-country (thr, ratio) from `table` to a decode table."""
    c = country_of_s1[d.i1.to_numpy()]
    thr = np.array([table.get(x, table["__global__"])[0] for x in np.unique(c)])
    rat = np.array([table.get(x, table["__global__"])[1] for x in np.unique(c)])
    code = np.searchsorted(np.unique(c), c)
    p, bst = d.p.to_numpy(), d.best.to_numpy()
    return d[(p >= thr[code]) & (p >= rat[code] * bst)]


def macro_f05_by_country(pred_i1, pred_y, n_true, country_of_s1):
    out = {}
    for c in np.unique(country_of_s1):
        idx = np.flatnonzero(country_of_s1 == c)
        remap = np.full(len(country_of_s1), -1, np.int64); remap[idx] = np.arange(len(idx))
        sel = remap[pred_i1] >= 0
        out[str(c)] = round(macro_f05(remap[pred_i1[sel]], pred_y[sel], n_true[idx], len(idx)), 4)
    return out
