#!/usr/bin/env python3
"""er3 command-line pipeline: every stage is a subcommand, every stage is resumable.

    python src/er3/pipeline.py <stage> --data-dir DATA --work-dir WORK --out-dir OUT [flags]

Stages (run in this order by ``all``)::

    prep            TSV -> normalised parquet caches, ground-truth index, train/val split
    finetune-embed  fine-tune the bi-encoder on ground-truth (S1, match) pairs   [GPU]
    embed           encode S1 samples / pools into float16 memmaps               [GPU]
    block           hash-key pairs  U  ANN top-k pairs (+ emb_cos) for train, val;
                    ANN top-k table for test
    features        pairwise features for the train / val pair frames
    train           LightGBM + probabilities on train / val pairs
    crossenc        cross-encoder on the uncertain band, blend weight on val     [GPU]
    tune            per-country (thr, ratio) on the validation decode table
    test            stream test S1 chunks -> pairs -> p -> decode -> two TSVs

Every intermediate artefact lives in ``--work-dir`` (see README, "Work-dir files") so a
stage that finds its outputs simply returns; delete a file to recompute it. Structure
(load_prepped, pair_codes, feats/predict chunking, write_lists, validation against the
FULL train pool) follows v2's run_pipeline.py.
"""
from __future__ import annotations

import argparse
import gc
import json
import os
import sys

import numpy as np
import pandas as pd

if __package__ in (None, ""):                      # run as a script: make `er3` importable
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import lightgbm as lgb                                                        # noqa: E402
from er3.crossenc import blend, load_crossencoder, rescore, select_band       # noqa: E402
from er3.embed import ann_topk, encode_to_memmap, load_encoder, open_memmap, pair_cosine  # noqa: E402
from er3.features import ANN_RANK_NONE, ANN_SIM_NONE, EMB_COS_NONE, FEATURES, features  # noqa: E402
from er3.finetune import build_pair_texts, finetune_biencoder, finetune_crossencoder, record_texts  # noqa: E402
from er3.keys import block_chunks, empty_pairs, pool_index                    # noqa: E402
from er3.log import log                                                       # noqa: E402
from er3.model import (GLOBAL, decide_by_country, decode_table, macro_f05,    # noqa: E402
                       score_breakdown, thresholds_for, train, tune_per_country)
from er3.normalize import prep                                                # noqa: E402

SEED = 42
W_GRID = (0.0, 0.3, 0.5, 0.7)      # cross-encoder blend weights tried on validation
DONE = ".done"                     # marker file written after a model directory is complete
STAGES = ["prep", "finetune-embed", "embed", "block", "features", "train", "crossenc", "tune", "test"]


# ============================================================================ helpers
def read_tsv(path):
    return pd.read_csv(path, sep="\t", dtype=str, keep_default_na=False, quoting=3)


def wp(args, *parts):
    """Path inside the work dir."""
    return os.path.join(args.work_dir, *parts)


def is_done(model_dir):
    return os.path.exists(os.path.join(model_dir, DONE))


def mark_done(model_dir):
    with open(os.path.join(model_dir, DONE), "w") as fh:
        fh.write("ok\n")


def resolve_device(args):
    """'auto' -> 'cuda' when torch sees a GPU, else 'cpu' (resolved once)."""
    if args.device == "auto":
        try:
            import torch
            args.device = "cuda" if torch.cuda.is_available() else "cpu"
        except ImportError:
            args.device = "cpu"
    return args.device


def is_cuda(args):
    return str(resolve_device(args)).startswith("cuda")


def use_embed(args):
    return not args.no_embed


def use_ce(args):
    return not args.no_ce


def load_prepped(path, args, tag):
    """Prepped frame from cache work/<tag>.parquet, built from one or several TSVs."""
    cache = wp(args, f"{tag}.parquet")
    if os.path.exists(cache):
        log(f"{tag}: loading cache {cache}")
        return pd.read_parquet(cache)
    df = read_tsv(path) if isinstance(path, str) else pd.concat([read_tsv(p) for p in path], ignore_index=True)
    log(f"{tag}: {len(df):,} rows read; normalising")
    out = prep(df, workers=args.workers)
    del df
    out.to_parquet(cache, index=False)
    log(f"{tag}: normalised and cached ({len(out):,} rows)")
    return out


def load_train_frames(args):
    D = args.data_dir
    s1 = load_prepped(f"{D}/train/train_source1.tsv", args, "s1_train")
    pool = load_prepped([f"{D}/train/train_source2.tsv", f"{D}/train/train_source3.tsv"], args, "pool_train")
    return s1, pool


def load_test_frames(args):
    D = args.data_dir
    s1 = load_prepped(f"{D}/test/test_source1.tsv", args, "s1_test")
    pool = load_prepped([f"{D}/test/test_source2.tsv", f"{D}/test/test_source3.tsv"], args, "pool_test")
    return s1, pool


def pair_codes(i1, i2):
    return np.asarray(i1).astype(np.int64) * (1 << 32) + np.asarray(i2).astype(np.int64)


def country_array(df):
    """Country per row as an object array of str."""
    return np.asarray(df.country.fillna("").astype(str).tolist(), dtype=object)


def texts_of(df):
    """Encoder text per row ('name_raw | addr_raw') as a pandas string Series (no prefix)."""
    return (df.name_raw.fillna("").astype("string[pyarrow]") + " | " + df.addr_raw.fillna("").astype("string[pyarrow]"))


def texts_at(df, idx):
    """Encoder texts of the rows `idx` of a prepped frame (list of str)."""
    return record_texts(df.iloc[np.asarray(idx)])


# ------------------------------------------------------------------ ground truth & split
def load_gt(args, s1, pool):
    """(t_i1, t_i2, n_true): ground-truth pair positions and true-match count per train S1."""
    path = wp(args, "gt_train.npz")
    if os.path.exists(path):
        z = np.load(path)
        return z["t_i1"], z["t_i2"], z["n_true"]
    gt = read_tsv(f"{args.data_dir}/train/train_ground_truth.tsv")
    s1_pos = pd.Index(s1.entity_id).get_indexer(gt.source1_entity_id)
    assert (s1_pos >= 0).all(), "ground-truth S1 ids missing from train_source1"
    lists = gt.matched_entity_ids.str.split(",")
    sizes = lists.map(lambda x: 0 if x == [""] else len(x)).to_numpy()
    n_true = np.zeros(len(s1), dtype=np.int32)
    n_true[s1_pos] = sizes
    t_i1 = np.repeat(s1_pos, sizes)
    t_ids = [x for l in lists for x in l if x]
    t_i2 = pd.Index(pool.entity_id).get_indexer(t_ids)
    ok = t_i2 >= 0
    log(f"ground truth: {len(gt):,} S1, {len(t_ids):,} matches ({(~ok).sum():,} ids not in pool), "
        f"singletons={np.mean(sizes == 0):.3f}, mean matches={sizes.mean():.2f}")
    t_i1, t_i2 = t_i1[ok].astype(np.int32), t_i2[ok].astype(np.int32)
    np.savez(path, t_i1=t_i1, t_i2=t_i2, n_true=n_true)
    return t_i1, t_i2, n_true


def load_split(args, n_s1, n_pool, t_i1, t_i2):
    """(A, B, sub): sorted train S1 sample, disjoint validation S1 sample, train pool subset
    (true matches of A + a random --distractor-frac of the pool). Cached in split.npz."""
    path = wp(args, "split.npz")
    meta = np.array([args.train_s1, args.val_s1, args.distractor_frac], dtype=np.float64)
    if os.path.exists(path):
        z = np.load(path)
        if np.allclose(z["meta"], meta) and int(z["n_s1"]) == n_s1:
            return z["A"], z["B"], z["sub"]
        log("split: parameters changed, resampling")
    rng = np.random.default_rng(SEED)
    perm = rng.permutation(n_s1)
    A = np.sort(perm[:args.train_s1])
    B = np.sort(perm[args.train_s1:args.train_s1 + args.val_s1])
    in_A = np.zeros(n_s1, bool)
    in_A[A] = True
    match_rows = np.unique(t_i2[in_A[t_i1]])
    sub = np.flatnonzero(rng.random(n_pool) < args.distractor_frac)
    sub = np.union1d(sub, match_rows).astype(np.int64)
    log(f"split: train S1={len(A):,}, val S1={len(B):,}, train pool subset={len(sub):,} "
        f"({len(match_rows):,} true matches of the train sample)")
    np.savez(path, A=A, B=B, sub=sub, meta=meta, n_s1=n_s1)
    return A, B, sub


def true_codes_of(t_i1, t_i2):
    return np.sort(pair_codes(t_i1, t_i2))


# ------------------------------------------------------------------ models (tiny / base)
def ensure_tiny(args):
    """Build the tiny bi-/cross-encoder under the work dir if they are missing."""
    bi, ce = wp(args, "tiny_biencoder"), wp(args, "tiny_crossencoder")
    if os.path.exists(os.path.join(bi, "modules.json")) and os.path.exists(os.path.join(ce, "config.json")):
        return bi, ce
    from er3.tiny import build_tiny_models
    s1, pool = load_train_frames(args)
    rng = np.random.default_rng(SEED)
    corpus = []
    for df in (s1, pool):
        take = rng.choice(len(df), size=min(len(df), 20_000), replace=False)
        corpus.extend(texts_at(df, np.sort(take)))
    del s1, pool
    return build_tiny_models(args.work_dir, corpus)


def biencoder_base(args):
    return ensure_tiny(args)[0] if args.tiny else args.embed_model


def crossencoder_base(args):
    return ensure_tiny(args)[1] if args.tiny else args.ce_model


def biencoder_dir(args):
    """Fine-tuned bi-encoder if finetune-embed completed, else the base model."""
    d = wp(args, "biencoder")
    return d if is_done(d) else biencoder_base(args)


# ------------------------------------------------------------------ chunked features / predict
def _group_bounds(pairs):
    pairs = pairs.sort_values(["i1", "i2"], kind="stable").reset_index(drop=True)
    return pairs, np.flatnonzero(np.diff(pairs.i1.to_numpy())) + 1


def _chunk_end(bounds, n, target):
    if target >= n:
        return n
    k = np.searchsorted(bounds, target)
    return n if k >= len(bounds) else int(bounds[k])


def feats_chunked(pairs, s1, other, workers, chunk_pairs):
    """Features for all pairs, per block of complete i1 groups -> (sorted pairs, DataFrame[FEATURES])."""
    pairs, bounds = _group_bounds(pairs)
    outs, start = [], 0
    while start < len(pairs):
        end = _chunk_end(bounds, len(pairs), start + chunk_pairs)
        outs.append(features(pairs.iloc[start:end], s1, other, workers))
        log(f"  features: {end:,}/{len(pairs):,} pairs")
        start = end
    X = pd.concat(outs, ignore_index=True) if outs else pd.DataFrame({c: [] for c in FEATURES})
    return pairs, X


def predict_chunked(model, pairs, s1, other, workers, chunk_pairs):
    """Features + LightGBM probabilities per block of complete i1 groups -> (sorted pairs, p float32)."""
    pairs, bounds = _group_bounds(pairs)
    p = np.empty(len(pairs), dtype=np.float32)
    start = 0
    while start < len(pairs):
        end = _chunk_end(bounds, len(pairs), start + chunk_pairs)
        X = features(pairs.iloc[start:end], s1, other, workers)
        p[start:end] = model.predict(X[FEATURES], num_threads=workers)
        log(f"  predict: {end:,}/{len(pairs):,} pairs")
        start = end
    return pairs, p


def predict_X(model, X, workers, chunk_rows=4_000_000):
    """LightGBM probabilities for a cached feature frame, in row blocks."""
    p = np.empty(len(X), dtype=np.float32)
    for s in range(0, len(X), chunk_rows):
        e = min(s + chunk_rows, len(X))
        p[s:e] = model.predict(X[FEATURES].iloc[s:e], num_threads=workers)
    return p


def write_lists(path, col, s1_ids, i1_sorted, id_strings):
    """One row per S1 entity (file order); id_strings aligned with i1_sorted (sorted by i1)."""
    bounds = np.searchsorted(i1_sorted, np.arange(len(s1_ids) + 1))
    with open(path, "w", newline="") as fh:
        fh.write(f"source1_entity_id\t{col}\n")
        for k, e in enumerate(s1_ids):
            fh.write(e + "\t" + ",".join(id_strings[bounds[k]:bounds[k + 1]]) + "\n")
    log(f"wrote {path}")


# ------------------------------------------------------------------ candidate pairs
def hash_pairs(s1_frame, index, s1_chunk):
    """All hash-key candidate pairs (i1 local to s1_frame, i2 in the indexed pool)."""
    parts = list(block_chunks(s1_frame, index, s1_chunk=s1_chunk))
    return pd.concat(parts, ignore_index=True) if parts else empty_pairs()


def union_pairs(hp, ann_idx=None, ann_sim=None):
    """Union of hash pairs (i1, i2, n_keys) with ANN top-k pairs -> DataFrame sorted by (i1, i2)
    [i1 int32, i2 int32, n_keys int8 (0 = ANN only), ann_sim float32 (-1 = hash only),
    ann_rank int8 (127 = hash only)]."""
    h_codes = pair_codes(hp.i1.to_numpy(), hp.i2.to_numpy())
    if ann_idx is not None and ann_idx.size:
        nq, k = ann_idx.shape
        qi = np.repeat(np.arange(nq, dtype=np.int64), k)
        pi = ann_idx.reshape(-1).astype(np.int64)
        rk = np.tile(np.arange(k, dtype=np.int64), nq)
        sm = np.asarray(ann_sim).reshape(-1).astype(np.float32)
        ok = pi >= 0
        qi, pi, rk, sm = qi[ok], pi[ok], rk[ok], sm[ok]
        a_codes = qi * (1 << 32) + pi
    else:
        a_codes = np.zeros(0, np.int64)
        rk = sm = np.zeros(0)
    codes = np.concatenate([h_codes, a_codes])
    uniq, inv = np.unique(codes, return_inverse=True)
    nh = len(h_codes)
    n_keys = np.zeros(len(uniq), np.int8)
    n_keys[inv[:nh]] = hp.n_keys.to_numpy().astype(np.int8, copy=False)
    a_sim = np.full(len(uniq), ANN_SIM_NONE, np.float32)
    a_rank = np.full(len(uniq), ANN_RANK_NONE, np.int8)
    if nh < len(codes):
        a_sim[inv[nh:]] = sm
        a_rank[inv[nh:]] = np.minimum(rk, 126).astype(np.int8)
    return pd.DataFrame({"i1": (uniq >> 32).astype(np.int32), "i2": (uniq & 0xFFFFFFFF).astype(np.int32),
                         "n_keys": n_keys, "ann_sim": a_sim, "ann_rank": a_rank})


def ann_blocks(args):
    return (2048, 500_000) if is_cuda(args) else (256, 100_000)


def ann_table(args, tag, q_path, p_path, q_country, p_country):
    """Cached ANN top-k (idx, sim) of the queries in q_path against the pool in p_path."""
    ip, sp = wp(args, f"ann_{tag}_idx.npy"), wp(args, f"ann_{tag}_sim.npy")
    if os.path.exists(ip) and os.path.exists(sp):
        idx, sim = np.load(ip), np.load(sp)
        if idx.shape[0] == len(q_country) and idx.shape[1] == args.ann_k:
            log(f"ann {tag}: loading cache {ip}")
            return idx, sim
    qb, pb = ann_blocks(args)
    idx, sim = ann_topk(q_path, p_path, q_country, p_country, k=args.ann_k, device=resolve_device(args),
                        q_block=qb, p_block=pb)
    np.save(ip, idx)
    np.save(sp, sim)
    log(f"ann {tag}: {idx.shape[0]:,} queries x k={idx.shape[1]} cached")
    return idx, sim


def attach_emb_cos(pairs, q_path, p_path, i1_global):
    pairs["emb_cos"] = pair_cosine(q_path, p_path, i1_global, pairs.i2.to_numpy(), block=500_000).astype(np.float32)
    return pairs


def build_pairs(args, s1f, poolf, q_tag, p_tag, tag, s1_chunk):
    """Hash-key pairs U ANN pairs (+ emb_cos) of s1f against poolf; i1/i2 local to the frames."""
    index = pool_index(poolf, cap=args.cap)
    hp = hash_pairs(s1f, index, s1_chunk)
    del index
    gc.collect()
    log(f"{tag}: {len(hp):,} hash-key pairs ({len(hp) / max(len(s1f), 1):.1f} per S1)")
    if use_embed(args):
        q_path, p_path = wp(args, f"emb_{q_tag}.npy"), wp(args, f"emb_{p_tag}.npy")
        idx, sim = ann_table(args, tag, q_path, p_path, country_array(s1f), country_array(poolf))
        pairs = union_pairs(hp, idx, sim)
        del hp, idx, sim
        pairs = attach_emb_cos(pairs, q_path, p_path, pairs.i1.to_numpy())
    else:
        pairs = union_pairs(hp)
        pairs["emb_cos"] = np.float32(EMB_COS_NONE)
    log(f"{tag}: {len(pairs):,} candidate pairs for {len(s1f):,} S1 ({len(pairs) / max(len(s1f), 1):.1f} per S1); "
        f"S1 with >=1 candidate: {pairs.i1.nunique():,}")
    return pairs


def log_recall(tag, pairs, y, n_true_sample):
    tot = max(int(n_true_sample.sum()), 1)
    y = y.astype(bool)
    hk = pairs.n_keys.to_numpy() > 0
    an = pairs.ann_rank.to_numpy() != ANN_RANK_NONE
    full = np.bincount(pairs.i1.to_numpy()[y], minlength=len(n_true_sample)) == n_true_sample
    log(f"{tag} recall: union {y.sum():,}/{tot:,} = {y.sum() / tot:.4f}; hash-only {(y & hk).sum() / tot:.4f}; "
        f"ann-only {(y & an).sum() / tot:.4f}; S1 with all matches blocked: {full.mean():.4f}")


# ============================================================================ stages
def prep_stage(args):
    s1, pool = load_train_frames(args)
    t_i1, t_i2, _ = load_gt(args, s1, pool)
    load_split(args, len(s1), len(pool), t_i1, t_i2)
    del s1, pool
    gc.collect()
    te1, pool = load_test_frames(args)
    log(f"prep: test S1={len(te1):,} countries={te1.country.value_counts().to_dict()}; pool={len(pool):,}")
    if args.tiny:
        ensure_tiny(args)


def finetune_embed_stage(args):
    if not use_embed(args):
        log("finetune-embed: skipped (--no-embed)")
        return
    out = wp(args, "biencoder")
    if is_done(out):
        log(f"finetune-embed: {out} already trained")
        return
    s1, pool = load_train_frames(args)
    t_i1, t_i2, _ = load_gt(args, s1, pool)
    _, B, _ = load_split(args, len(s1), len(pool), t_i1, t_i2)
    gt = read_tsv(f"{args.data_dir}/train/train_ground_truth.tsv")
    gt = gt[~gt.source1_entity_id.isin(s1.entity_id.to_numpy()[B])]     # keep validation S1 unseen
    pairs = build_pair_texts(s1, pool, gt, max_pairs=args.max_pairs)
    del s1, pool, gt
    gc.collect()
    base = biencoder_base(args)
    finetune_biencoder(pairs, base, out, device=resolve_device(args), epochs=1, batch_size=args.batch_size,
                       max_pairs=args.max_pairs, fp16=True, max_len=64)
    mark_done(out)


def _copy_rows(src_path, dst_path, rows, block=500_000):
    """dst = src[rows] as a float16 .npy memmap (+ .shape.json), chunked."""
    src = open_memmap(src_path)
    dst = np.lib.format.open_memmap(dst_path, mode="w+", dtype=np.float16, shape=(len(rows), src.shape[1]))
    for s in range(0, len(rows), block):
        dst[s:s + block] = src[rows[s:s + block]]
    dst.flush()
    del dst, src
    with open(dst_path + ".shape.json", "w") as fh:
        json.dump({"shape": [int(len(rows)), int(open_memmap(dst_path).shape[1])], "dtype": "float16"}, fh)


def embed_stage(args):
    if not use_embed(args):
        log("embed: skipped (--no-embed)")
        return
    device = resolve_device(args)
    model = load_encoder(biencoder_dir(args), device)
    kw = dict(batch_size=args.encode_batch, max_len=64, device=device, prefix="query: ")
    s1, pool = load_train_frames(args)
    t_i1, t_i2, _ = load_gt(args, s1, pool)
    A, B, sub = load_split(args, len(s1), len(pool), t_i1, t_i2)
    encode_to_memmap(texts_of(s1.iloc[A]), model, wp(args, "emb_s1_train_A.npy"), **kw)
    encode_to_memmap(texts_of(s1.iloc[B]), model, wp(args, "emb_s1_train_B.npy"), **kw)
    del s1
    encode_to_memmap(texts_of(pool), model, wp(args, "emb_pool_train.npy"), **kw)
    del pool
    gc.collect()
    sub_path = wp(args, "emb_pool_train_sub.npy")
    if not (os.path.exists(sub_path) and os.path.exists(sub_path + ".shape.json")):
        _copy_rows(wp(args, "emb_pool_train.npy"), sub_path, sub)
        log(f"embed: pool subset {len(sub):,} rows -> {sub_path}")
    te1, pool = load_test_frames(args)
    encode_to_memmap(texts_of(te1), model, wp(args, "emb_s1_test.npy"), **kw)
    del te1
    encode_to_memmap(texts_of(pool), model, wp(args, "emb_pool_test.npy"), **kw)


def block_stage(args):
    s1, pool = load_train_frames(args)
    t_i1, t_i2, n_true = load_gt(args, s1, pool)
    A, B, sub = load_split(args, len(s1), len(pool), t_i1, t_i2)
    true_codes = true_codes_of(t_i1, t_i2)
    path = wp(args, "pairs_train.parquet")
    if not os.path.exists(path):
        s1A, poolS = s1.iloc[A].reset_index(drop=True), pool.iloc[sub].reset_index(drop=True)
        pairs = build_pairs(args, s1A, poolS, "s1_train_A", "pool_train_sub", "train", args.s1_chunk)
        pairs["y"] = np.isin(pair_codes(A[pairs.i1.to_numpy()], sub[pairs.i2.to_numpy()]), true_codes).astype(np.int8)
        log_recall("train", pairs, pairs.y.to_numpy(), n_true[A])
        pairs.to_parquet(path, index=False)
        del s1A, poolS, pairs
        gc.collect()
    path = wp(args, "pairs_val.parquet")
    if not os.path.exists(path):
        s1B = s1.iloc[B].reset_index(drop=True)
        pairs = build_pairs(args, s1B, pool, "s1_train_B", "pool_train", "val", args.s1_chunk)
        pairs["y"] = np.isin(pair_codes(B[pairs.i1.to_numpy()], pairs.i2.to_numpy()), true_codes).astype(np.int8)
        log_recall("val", pairs, pairs.y.to_numpy(), n_true[B])
        pairs.to_parquet(path, index=False)
        del s1B, pairs
        gc.collect()
    del s1, pool
    gc.collect()
    if use_embed(args):                     # ANN table for the test split (used by the test stage)
        te1, pool = load_test_frames(args)
        ann_table(args, "test", wp(args, "emb_s1_test.npy"), wp(args, "emb_pool_test.npy"),
                  country_array(te1), country_array(pool))


def features_stage(args):
    s1, pool = load_train_frames(args)
    t_i1, t_i2, _ = load_gt(args, s1, pool)
    A, B, sub = load_split(args, len(s1), len(pool), t_i1, t_i2)
    jobs = [("train", s1.iloc[A].reset_index(drop=True), pool.iloc[sub].reset_index(drop=True)),
            ("val", s1.iloc[B].reset_index(drop=True), pool)]
    for tag, s1f, poolf in jobs:
        path = wp(args, f"X_{tag}.parquet")
        if os.path.exists(path):
            log(f"features {tag}: cache {path} exists")
            continue
        pairs = pd.read_parquet(wp(args, f"pairs_{tag}.parquet"))
        pairs, X = feats_chunked(pairs, s1f, poolf, args.workers, args.chunk_pairs)
        X["y"], X["i1"], X["i2"] = pairs.y.to_numpy(), pairs.i1.to_numpy(), pairs.i2.to_numpy()
        X.to_parquet(path, index=False)
        log(f"features {tag}: {len(X):,} rows x {len(FEATURES)} features cached")
        del pairs, X
        gc.collect()


def train_stage(args):
    model_path = wp(args, "model.txt")
    if all(os.path.exists(wp(args, f)) for f in ("model.txt", "p_train.npy", "p_val.npy")):
        log("train: model.txt, p_train.npy, p_val.npy exist")
        return
    X = pd.read_parquet(wp(args, "X_train.parquet"))
    if os.path.exists(model_path):
        model = lgb.Booster(model_file=model_path)
    else:
        model = train(X[FEATURES], X.y.to_numpy(), X.i1.to_numpy(), params={"n_jobs": args.workers})
        model.save_model(model_path)
    np.save(wp(args, "p_train.npy"), predict_X(model, X, args.workers))
    del X
    gc.collect()
    Xv = pd.read_parquet(wp(args, "X_val.parquet"))
    p_val = predict_X(model, Xv, args.workers)
    np.save(wp(args, "p_val.npy"), p_val)
    log(f"train: validation pairs={len(Xv):,} mean p={p_val.mean():.4f} pos rate={Xv.y.mean():.4f}")


# ------------------------------------------------------------------ validation helpers
def load_val(args):
    """(i1 local to B, i2, y, p_lgb) of the validation pairs."""
    Xv = pd.read_parquet(wp(args, "X_val.parquet"), columns=["i1", "i2", "y"])
    return Xv.i1.to_numpy(), Xv.i2.to_numpy(), Xv.y.to_numpy(), np.load(wp(args, "p_val.npy"))


def ce_active(args):
    """Cross-encoder trained and blend weight > 0 (as tuned on validation)."""
    wj = wp(args, "ce", "w.json")
    if not use_ce(args) or not is_done(wp(args, "ce")) or not os.path.exists(wj):
        return False, 0.0
    w = float(json.load(open(wj))["w"])
    return w > 0.0, w


def tune_mask(args, n_val):
    """Validation S1 used for tuning: all when no cross-encoder, else the half not used to train it."""
    if not use_ce(args):
        return np.ones(n_val, bool)
    return np.arange(n_val) % 2 == 1


def val_decode(i1, i2, p, B, true_codes, n_true_B, country_B, keep):
    """Decode table of the validation pairs restricted to the S1 in `keep` (i1 remapped)."""
    d = decode_table(i1, i2, p)
    y_d = np.isin(pair_codes(B[d.i1.to_numpy()], d.i2.to_numpy()), true_codes).astype(np.float64)
    new_id = np.cumsum(keep) - 1
    m = keep[d.i1.to_numpy()]
    d = d[m].reset_index(drop=True)
    d["i1"] = new_id[d.i1.to_numpy()].astype(np.int32)
    return d, y_d[m], n_true_B[keep], country_B[keep]


def val_score(d, y_d, n_true, country, table):
    kept = decide_by_country(d, country, table)
    return macro_f05(kept.i1.to_numpy(), y_d[kept.index.to_numpy()], n_true, len(n_true))


def blended_val_p(args, p_lgb):
    """Validation probabilities after the tuned cross-encoder blend (or p_lgb when inactive)."""
    active, w = ce_active(args)
    if not active:
        return p_lgb, 0.0
    p_ce = np.load(wp(args, "p_val_ce.npy"))
    band = ~np.isnan(p_ce)
    p = p_lgb.copy()
    p[band] = blend(p_lgb[band], p_ce[band], w)
    return p, w


def crossenc_stage(args):
    if not use_ce(args):
        log("crossenc: skipped (--no-ce)")
        return
    ce_dir = wp(args, "ce")
    if is_done(ce_dir) and os.path.exists(wp(args, "p_val_ce.npy")) and os.path.exists(os.path.join(ce_dir, "w.json")):
        log("crossenc: model, p_val_ce.npy and w.json exist")
        return
    device = resolve_device(args)
    s1, pool = load_train_frames(args)
    t_i1, t_i2, n_true = load_gt(args, s1, pool)
    A, B, sub = load_split(args, len(s1), len(pool), t_i1, t_i2)
    vi1, vi2, vy, vp = load_val(args)
    s1B = s1.iloc[B].reset_index(drop=True)
    if not is_done(ce_dir):
        # ---- training triples: uncertain band of train pairs + of the CE half of validation
        Xt = pd.read_parquet(wp(args, "X_train.parquet"), columns=["i1", "i2", "y"])
        pt = np.load(wp(args, "p_train.npy"))
        assert len(pt) == len(Xt), "p_train.npy does not match X_train.parquet (rerun the train stage)"
        s1A, poolS = s1.iloc[A].reset_index(drop=True), pool.iloc[sub].reset_index(drop=True)
        bt = np.flatnonzero(select_band(pt, args.ce_lo, args.ce_hi))
        bv = np.flatnonzero(select_band(vp, args.ce_lo, args.ce_hi) & ~tune_mask(args, len(B))[vi1])
        log(f"crossenc: band pairs train={len(bt):,} val(CE half)={len(bv):,} of "
            f"{len(pt):,}/{len(vp):,}; band=[{args.ce_lo}, {args.ce_hi}]")
        y_all = np.concatenate([Xt.y.to_numpy()[bt], vy[bv]]).astype(np.int8)
        src = np.concatenate([np.zeros(len(bt), np.int8), np.ones(len(bv), np.int8)])
        rows = np.concatenate([bt, bv])
        rng = np.random.default_rng(SEED)
        pos, neg = np.flatnonzero(y_all == 1), np.flatnonzero(y_all == 0)
        n = min(len(pos), len(neg), args.ce_max_train // 2)
        if n == 0:
            log("crossenc: WARNING no positives or no negatives in the band; skipping cross-encoder")
            os.makedirs(ce_dir, exist_ok=True)
            json.dump({"w": 0.0, "scores": {}}, open(os.path.join(ce_dir, "w.json"), "w"))
            np.save(wp(args, "p_val_ce.npy"), np.full(len(vp), np.nan, np.float32))
            mark_done(ce_dir)
            return
        pick = np.concatenate([rng.choice(pos, n, replace=False), rng.choice(neg, n, replace=False)])
        rng.shuffle(pick)
        log(f"crossenc: {len(pick):,} balanced training pairs ({n:,} pos / {n:,} neg)")
        a_texts = np.empty(len(pick), dtype=object)
        b_texts = np.empty(len(pick), dtype=object)
        for tag, s1f, poolf, li1, li2 in (("train", s1A, poolS, Xt.i1.to_numpy(), Xt.i2.to_numpy()),
                                          ("val", s1B, pool, vi1, vi2)):
            m = src[pick] == (0 if tag == "train" else 1)
            r = rows[pick[m]]
            a_texts[m] = np.array(texts_at(s1f, li1[r]), dtype=object)
            b_texts[m] = np.array(texts_at(poolf, li2[r]), dtype=object)
        triples = list(zip(a_texts.tolist(), b_texts.tolist(), y_all[pick].astype(np.float32).tolist()))
        del Xt, pt, s1A, poolS, a_texts, b_texts
        gc.collect()
        finetune_crossencoder(triples, crossencoder_base(args), ce_dir, device=device, epochs=1, batch_size=32,
                              max_len=96, fp16=True)
        mark_done(ce_dir)
        del triples
        gc.collect()
    # ---- rescore the validation band and pick the blend weight on the tuning half
    p_ce_path = wp(args, "p_val_ce.npy")
    band = np.flatnonzero(select_band(vp, args.ce_lo, args.ce_hi))
    if os.path.exists(p_ce_path) and len(np.load(p_ce_path)) == len(vp):
        p_val_ce = np.load(p_ce_path)
    else:
        model = load_crossencoder(ce_dir, device, max_len=96)
        p_val_ce = np.full(len(vp), np.nan, np.float32)
        p_val_ce[band] = rescore(model, texts_at(s1B, vi1[band]), texts_at(pool, vi2[band]),
                                 batch_size=args.batch_size, device=device)
        np.save(p_ce_path, p_val_ce)
        del model
        gc.collect()
    true_codes = true_codes_of(t_i1, t_i2)
    keep = tune_mask(args, len(B))
    country_B = country_array(s1B)
    scores = {}
    for w in W_GRID:
        p = vp.copy()
        p[band] = blend(vp[band], p_val_ce[band], w)
        d, y_d, nt, cs = val_decode(vi1, vi2, p, B, true_codes, n_true[B], country_B, keep)
        table = tune_per_country(d, y_d, nt, cs, len(nt))
        scores[w] = val_score(d, y_d, nt, cs, table)
        log(f"crossenc: blend w={w}: tuned macro F0.5={scores[w]:.4f} on {len(nt):,} validation S1")
    best_w = max(scores, key=lambda w: (scores[w], -w))
    json.dump({"w": best_w, "scores": {str(k): v for k, v in scores.items()}, "n_band_val": int(len(band))},
              open(os.path.join(ce_dir, "w.json"), "w"))
    log(f"crossenc: best blend weight w={best_w}")


def tune_stage(args):
    s1, pool = load_train_frames(args)
    t_i1, t_i2, n_true = load_gt(args, s1, pool)
    _, B, _ = load_split(args, len(s1), len(pool), t_i1, t_i2)
    country_B = country_array(s1.iloc[B])
    del s1, pool
    gc.collect()
    vi1, vi2, vy, vp = load_val(args)
    p, w = blended_val_p(args, vp)
    true_codes = true_codes_of(t_i1, t_i2)
    keep = tune_mask(args, len(B))
    n_true_B = n_true[B]
    oracle = macro_f05(vi1[vy > 0], vy[vy > 0].astype(np.float64), n_true_B, len(B))
    log(f"tune: val oracle F0.5 (blocking ceiling, all val S1) = {oracle:.4f}; cross-encoder w={w}")
    d, y_d, nt, cs = val_decode(vi1, vi2, p, B, true_codes, n_true_B, country_B, keep)
    table = tune_per_country(d, y_d, nt, cs, len(nt))
    stats = score_breakdown(d, y_d, nt, cs, table)
    json.dump({"table": {c: [round(float(t), 4), round(float(r), 4)] for c, (t, r) in table.items()}, "w": w,
               "val_f05": stats[GLOBAL]["f05"], "oracle": oracle, "n_val_s1": int(len(nt)),
               "by_country": stats}, open(wp(args, "tuned.json"), "w"), indent=1)
    log(f"tune: saved tuned.json (global thr={table[GLOBAL][0]:.3f} ratio={table[GLOBAL][1]}, "
        f"val F0.5={stats[GLOBAL]['f05']:.4f})")


def load_tuned(args):
    t = json.load(open(wp(args, "tuned.json")))
    return {c: (float(v[0]), float(v[1])) for c, v in t["table"].items()}, float(t.get("w", 0.0)), t


def _chunk_paths(args, k):
    return [wp(args, f"test_pairs_{k:04d}_{c}.npy") for c in ("i1", "i2", "p", "plgb")]


def test_stage(args):
    table, w, tuned = load_tuned(args)
    log(f"test: thresholds {table} (val F0.5={tuned['val_f05']:.4f})")
    model = lgb.Booster(model_file=wp(args, "model.txt"))
    te1, pool = load_test_frames(args)
    n = len(te1)
    log(f"test: S1={n:,} countries={te1.country.value_counts().to_dict()}; pool={len(pool):,}")
    cn = country_array(te1)
    device = resolve_device(args)
    ce_on, w = ce_active(args)
    q_path, p_path = wp(args, "emb_s1_test.npy"), wp(args, "emb_pool_test.npy")
    ann_idx = ann_sim = None
    if use_embed(args):
        ann_idx, ann_sim = ann_table(args, "test", q_path, p_path, cn, country_array(pool))
    starts = list(range(0, n, args.s1_chunk))
    todo = [k for k, s in enumerate(starts) if not all(os.path.exists(f) for f in _chunk_paths(args, k))]
    log(f"test: {len(starts)} chunks of {args.s1_chunk:,} S1, {len(todo)} still to score (cached chunks are skipped)")
    ce_model = load_crossencoder(wp(args, "ce"), device, max_len=96) if (ce_on and todo) else None
    index = pool_index(pool, cap=args.cap) if todo else None
    for k, s in enumerate(starts):
        if k not in todo:
            continue
        e = min(s + args.s1_chunk, n)
        sub1 = te1.iloc[s:e].reset_index(drop=True)
        hp = hash_pairs(sub1, index, e - s)
        if use_embed(args):
            pairs = union_pairs(hp, ann_idx[s:e], ann_sim[s:e])
            pairs = attach_emb_cos(pairs, q_path, p_path, pairs.i1.to_numpy() + s)
        else:
            pairs = union_pairs(hp)
            pairs["emb_cos"] = np.float32(EMB_COS_NONE)
        del hp
        if len(pairs):
            pairs, p_lgb = predict_chunked(model, pairs, sub1, pool, args.workers, args.chunk_pairs)
        else:
            p_lgb = np.zeros(0, np.float32)
        p = p_lgb.copy()
        if ce_on and len(pairs):
            band = np.flatnonzero(select_band(p_lgb, args.ce_lo, args.ce_hi))
            cap = max(1, int(np.ceil(args.ce_max_rescore * (e - s) / n)))
            if len(band) > cap:            # keep the pairs closest to their country's threshold
                thr_rows = thresholds_for(cn[pairs.i1.to_numpy()[band] + s], table)
                order = np.argsort(np.abs(p_lgb[band] - thr_rows), kind="stable")
                band = np.sort(band[order[:cap]])
            if len(band):
                p_ce = rescore(ce_model, texts_at(sub1, pairs.i1.to_numpy()[band]),
                               texts_at(pool, pairs.i2.to_numpy()[band]), batch_size=args.batch_size, device=device)
                p[band] = blend(p_lgb[band], p_ce, w)
            log(f"test chunk {k}: cross-encoder rescored {len(band):,} band pairs (w={w})")
        i1, i2, pp, pl = _chunk_paths(args, k)
        np.save(i1, (pairs.i1.to_numpy() + s).astype(np.int32))
        np.save(i2, pairs.i2.to_numpy().astype(np.int32))
        np.save(pp, p.astype(np.float32))
        np.save(pl, p_lgb.astype(np.float32))
        log(f"test chunk {k}: {len(pairs):,} pairs, S1 {s:,}-{e:,}/{n:,}")
        del pairs, p, p_lgb, sub1
        gc.collect()
    del index, ce_model, ann_idx, ann_sim
    gc.collect()
    I1, I2, P = [], [], []
    for k in range(len(starts)):
        i1, i2, pp, _ = _chunk_paths(args, k)
        I1.append(np.load(i1))
        I2.append(np.load(i2))
        P.append(np.load(pp))
    pairs = pd.DataFrame({"i1": np.concatenate(I1), "i2": np.concatenate(I2)})
    p = np.concatenate(P)
    del I1, I2, P
    log(f"test: {len(pairs):,} pairs ({len(pairs) / n:.1f} per S1); S1 with >=1 candidate: {pairs.i1.nunique():,}")
    d = decode_table(pairs.i1.to_numpy(), pairs.i2.to_numpy(), p)
    kept = decide_by_country(d, cn, table).sort_values(["i1", "p"], ascending=[True, False], kind="stable")
    del d
    pool_ids = pool.entity_id.to_numpy(dtype=object)
    s1_ids = te1.entity_id.tolist()
    os.makedirs(args.out_dir, exist_ok=True)
    write_lists(os.path.join(args.out_dir, "matching_results.tsv"), "matched_entity_ids", s1_ids,
                kept.i1.to_numpy(), pool_ids[kept.i2.to_numpy()].tolist())
    write_lists(os.path.join(args.out_dir, "candidate_pairs.tsv"), "candidate_entity_ids", s1_ids,
                pairs.i1.to_numpy(), pool_ids[pairs.i2.to_numpy()].tolist())
    n_match = np.bincount(kept.i1.to_numpy(), minlength=n)
    log(f"test: {np.mean(n_match > 0):.4f} of S1 matched; mean matches={n_match.mean():.2f}; "
        f"by country: { {c: round(float(np.mean(n_match[cn == c] > 0)), 4) for c in np.unique(cn)} }")


def all_stage(args):
    for name in STAGES:
        log(f"===== stage {name} =====")
        STAGE_FN[name](args)
        gc.collect()


STAGE_FN = {"prep": prep_stage, "finetune-embed": finetune_embed_stage, "embed": embed_stage, "block": block_stage,
            "features": features_stage, "train": train_stage, "crossenc": crossenc_stage, "tune": tune_stage,
            "test": test_stage, "all": all_stage}


# ============================================================================ CLI
def build_parser():
    common = argparse.ArgumentParser(add_help=False)
    g = common.add_argument_group("shared")
    g.add_argument("--data-dir", required=True, help="dir with train/ and test/ TSVs")
    g.add_argument("--work-dir", default="work", help="cache dir for all intermediate artefacts")
    g.add_argument("--out-dir", default="output", help="where the two submission TSVs are written")
    g.add_argument("--device", default="auto", choices=["auto", "cpu", "cuda"])
    g.add_argument("--tiny", action="store_true", help="use locally built tiny models (CPU smoke test)")
    g.add_argument("--no-ce", action="store_true", help="skip the cross-encoder stage / rescoring")
    g.add_argument("--no-embed", action="store_true", help="skip the bi-encoder: hash-key blocking only")
    g.add_argument("--workers", type=int, default=4)
    s = common.add_argument_group("sampling / blocking")
    s.add_argument("--train-s1", type=int, default=300_000, help="S1 entities sampled for LightGBM training")
    s.add_argument("--val-s1", type=int, default=60_000, help="disjoint S1 sample scored against the full pool")
    s.add_argument("--distractor-frac", type=float, default=0.10, help="fraction of the pool kept as train distractors")
    s.add_argument("--cap", type=int, default=150, help="max S2/S3 records per blocking key")
    s.add_argument("--chunk-pairs", type=int, default=8_000_000, help="pairs per feature/predict block")
    s.add_argument("--s1-chunk", type=int, default=100_000, help="S1 rows per streamed test chunk")
    s.add_argument("--ann-k", type=int, default=20, help="ANN neighbours per S1 (same country)")
    m = common.add_argument_group("neural models")
    m.add_argument("--embed-model", default="intfloat/multilingual-e5-small")
    m.add_argument("--ce-model", default="xlm-roberta-base")
    m.add_argument("--max-pairs", type=int, default=1_500_000, help="max (S1, match) pairs for bi-encoder fine-tuning")
    m.add_argument("--ce-lo", type=float, default=0.2, help="lower edge of the uncertain LightGBM band")
    m.add_argument("--ce-hi", type=float, default=0.98, help="upper edge of the uncertain LightGBM band")
    m.add_argument("--ce-max-train", type=int, default=300_000, help="max balanced cross-encoder training pairs")
    m.add_argument("--ce-max-rescore", type=int, default=6_000_000,
                   help="max test pairs rescored by the cross-encoder (~1 h per 6M on a T4)")
    m.add_argument("--batch-size", type=int, default=256, help="batch size for bi-encoder training and cross-encoder rescoring")
    m.add_argument("--encode-batch", type=int, default=512, help="batch size for embedding (inference, max_len 64)")
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="stage", required=True)
    for name in STAGES + ["all"]:
        sp = sub.add_parser(name, parents=[common], help=f"run the {name} stage" if name != "all" else "run every stage")
        sp.set_defaults(func=STAGE_FN[name])
    return ap


def main(argv=None):
    args = build_parser().parse_args(argv)
    os.makedirs(args.work_dir, exist_ok=True)
    os.makedirs(args.out_dir, exist_ok=True)
    log(f"er3 {args.stage}: data={args.data_dir} work={args.work_dir} out={args.out_dir} device={args.device} "
        f"tiny={args.tiny} no_ce={args.no_ce} no_embed={args.no_embed} workers={args.workers}")
    args.func(args)
    log(f"er3 {args.stage}: done")
    return 0


if __name__ == "__main__":
    sys.exit(main())
