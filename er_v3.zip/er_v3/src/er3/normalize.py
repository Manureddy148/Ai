"""Text normalisation for business names and addresses (adapted from v2).

All functions are pure and operate on single strings; `prep()` applies them to a whole
source frame with a process pool because the corpus has ~10M records per split. v3
additionally keeps the raw strings (name_raw, addr_raw) for the neural encoders,
which work on the original script rather than the ASCII-folded form.
"""
import re
from multiprocessing import Pool

import numpy as np
import pandas as pd
from unidecode import unidecode

NAME_ABBR = {
    "corp": "corporation", "co": "company", "inc": "incorporated", "ltd": "limited",
    "pvt": "private", "intl": "international", "mfg": "manufacturing", "svc": "services",
    "svcs": "services", "bros": "brothers", "assoc": "associates", "natl": "national",
    "tech": "technologies", "grp": "group", "ent": "enterprises", "cie": "compagnie",
    "ste": "societe", "llp": "llp",
}
LEGAL = {
    "corporation", "company", "incorporated", "limited", "private", "llc", "llp", "lp",
    "plc", "pllc", "the", "and", "of", "dba", "pvt", "opc", "inc", "ltd", "co",
    "sarl", "sas", "sasu", "sa", "eurl", "sci", "snc", "societe", "compagnie", "et",
}
TLD = {"com", "in", "net", "org", "co", "io", "fr", "us", "biz", "info"}
ADDR_ABBR = {
    "rd": "road", "st": "street", "str": "street", "ave": "avenue", "av": "avenue",
    "blvd": "boulevard", "bd": "boulevard", "dr": "drive", "ln": "lane", "hwy": "highway",
    "pkwy": "parkway", "ct": "court", "pl": "place", "sq": "square", "ste": "suite",
    "apt": "apartment", "fl": "floor", "flr": "floor", "bldg": "building",
    "nr": "near", "opp": "opposite", "ngr": "nagar", "clny": "colony", "sec": "sector",
    "mkt": "market", "stn": "station", "marg": "road", "salai": "road",
    "fbg": "faubourg", "chem": "chemin", "imp": "impasse",
}
ADDR_STOP = {"near", "opposite", "behind", "beside", "next", "to", "the", "of", "and",
             "no", "number", "de", "la", "le", "du", "des", "null", "none", "nan", "n", "a"}

_punct = re.compile(r"[^a-z0-9 ]+")
_space = re.compile(r"\s+")
_digits = re.compile(r"\d+")
_postal = re.compile(r"\b(\d{5,6})\b")
_dotted = re.compile(r"(?<![a-z])(?:[a-z]\.){2,}[a-z]?(?![a-z])")
_ALIAS = re.compile(
    r"\b(?:d\s*/\s*b\s*/\s*a|d\.b\.a\.?|dba|doing business as|trading as|t\s*/\s*a"
    r"|a\s*/\s*k\s*/\s*a|a\.k\.a\.?|also known as|formerly(?: known as)?)\b", re.I)
_NULLS = {"", "null", "none", "nan", "n/a", "na", "-"}


def clean_raw(s):
    """Raw string for the neural encoders: str(), whitespace-collapsed, 'null'-like -> ''."""
    if s is None or (isinstance(s, float) and np.isnan(s)):
        return ""
    s = _space.sub(" ", str(s)).strip()
    return "" if s.lower() in _NULLS else s


def basic(s):
    """ASCII-fold (incl. Indic scripts via unidecode), lowercase, strip punctuation."""
    s = unidecode(str(s)).lower()
    s = s.replace("&", " and ").replace("@", " at ")
    s = _dotted.sub(lambda m: m.group(0).replace(".", ""), s)
    s = _punct.sub(" ", s)
    return _space.sub(" ", s).strip()


def norm_name(raw):
    """Normalised name with legal suffixes and web TLDs removed ('core name')."""
    s = basic(" ".join(_ALIAS.split(str(raw))))
    toks = [NAME_ABBR.get(t, t) for t in s.split()]
    if len(toks) > 1 and toks[-1] in TLD:          # 'maurewilliams com' -> 'maurewilliams'
        toks = toks[:-1]
    core = [t for t in toks if t not in LEGAL]
    return " ".join(core) if core else " ".join(toks)


def norm_addr(raw):
    """Normalised address with abbreviations expanded and filler tokens removed.

    Returns (addr_c, postal, house, nums) where postal is the 5-6 digit code (last one
    in the raw string), house the first token containing a digit, and nums the
    space-joined digit runs excluding the postal code.
    """
    postal = (_postal.findall(str(raw)) or [""])[-1]
    s = basic(raw)
    toks = [ADDR_ABBR.get(t, t) for t in s.split()]
    toks = [t for t in toks if t not in ADDR_STOP]
    house = next((t for t in toks if any(c.isdigit() for c in t)), "")
    nums = _digits.findall(s)
    if postal and postal in nums:
        nums.remove(postal)
    return " ".join(toks), postal, house, " ".join(dict.fromkeys(nums))


def _prep_chunk(args):
    names, addrs = args
    out_name = [norm_name(n) for n in names]
    out_addr = [norm_addr(a) for a in addrs]
    return out_name, out_addr


def _str_col(values):
    return pd.Series(values, dtype="string[pyarrow]")


def prep(df, workers=4, chunk=50_000):
    """Normalise a source frame (entity_id, business_name, business_address, country).

    Returns DataFrame[entity_id, country, name_c, addr_c, postal, house, nums,
    non_ascii(int8), src('S1'/'S2'/'S3'), name_raw, addr_raw]; country is lower-cased
    ASCII, name_raw/addr_raw are the original strings ('null'-like tokens -> '').
    """
    name_raw = [clean_raw(s) for s in df.business_name.tolist()]
    addr_raw = [clean_raw(s) for s in df.business_address.tolist()]
    jobs = [(name_raw[i:i + chunk], addr_raw[i:i + chunk]) for i in range(0, len(df), chunk)]
    name_c, addr_rows = [], []
    if workers and workers > 1 and len(jobs) > 1:
        with Pool(workers) as pool:
            for n, a in pool.imap(_prep_chunk, jobs):
                name_c.extend(n)
                addr_rows.extend(a)
    else:
        for job in jobs:
            n, a = _prep_chunk(job)
            name_c.extend(n)
            addr_rows.extend(a)
    non_ascii = np.fromiter((any(ord(c) > 127 for c in s) for s in name_raw), dtype=np.int8, count=len(name_raw))
    ids = df.entity_id.astype(str)
    return pd.DataFrame({
        "entity_id": ids.to_numpy(dtype=object),
        "country": _str_col([basic(c) for c in df.country.tolist()]),
        "name_c": _str_col(name_c),
        "addr_c": _str_col([r[0] for r in addr_rows]),
        "postal": _str_col([r[1] for r in addr_rows]),
        "house": _str_col([r[2] for r in addr_rows]),
        "nums": _str_col([r[3] for r in addr_rows]),
        "non_ascii": non_ascii,
        "src": ids.str[:2].to_numpy(dtype=object),
        "name_raw": _str_col(name_raw),
        "addr_raw": _str_col(addr_raw),
    })
